#Arrange all even numbers first and then odd numbers later on the same array
Input:
    9
    21 21 56 43 66 0 23 8 67
Output:
    56 66 0 8 21 21 43 23 67
    
def arrange(arr):
    n=len(arr)
    e=0
    o=0 
    while o<n:
        if arr[o]%2==0:
            arr[o],arr[e]=arr[e],arr[o]
            e+=1
        o+=1
    return arr
n=int(input())
arr=list(map(int,input().split()))
print(arrange(arr))




