def pri(n):
    if n<=1:
        return False
    for i in range(2,int(n**0.5)+1):
        if n%i==0:
            return False
    return True
def primesum(n):
    p=[]
    for i in range(2,n+1):
        if pri(i):
            p.append(i)
    return p
def find(p,n):
    sum=0
    res=[]
    for i in range(len(p)):
        #print(p[i])
        sum+=p[i]
        if sum==2:
            continue
        if sum in p:
            res.append(p)
    print(res)
    return res
                 
n=int(input())
p=primesum(n)
res=find(p,n)
print(len(res))



#Some prime numbers can be expressed as the sum of other consecutive prime numbers:
'''17=>2+3+5+7
input:20 output:2
2,7,11 are the primes in which we need to alwats start with 2 an dthe others should be consecutive primes


'''
