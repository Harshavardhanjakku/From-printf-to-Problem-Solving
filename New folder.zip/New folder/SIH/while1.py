'''a=int(input("Enter a num: "))
i=1
while(i<=a):
    print(i,end=" ")
    i+=1'''

a=int(input("Enter a num: "))
i=1
while(a>=i):
    print(i)
    i-=1
