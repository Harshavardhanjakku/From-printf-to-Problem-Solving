'''### 🔹 **Lists (Complete these first)**

1. Write a Python program to **find the sum of all elements in a list**.
2. Remove all **duplicates from a list** without using set().
3. Sort a list of integers **without using `sort()` or `sorted()`**.
4. Find the **second largest number** in a list.
5. Reverse a list **in-place**.
6. Count the number of **even and odd numbers** in a list.
7. Merge two sorted lists **into one sorted list**.
8. Check if a list is **palindrome**.
9. Rotate a list by k positions.
10. Find **common elements** in two lists.

---

### 🟣 **Dictionaries (Super powerful for placements!)**

1. Count the **frequency of each character** in a string using a dictionary.
2. Merge two dictionaries.
3. Create a dictionary from two lists (keys and values).
4. Sort a dictionary by **values**.
5. Remove duplicates from a list of dictionaries.
6. Check if a key exists in a dictionary.
7. Invert a dictionary (swap keys and values).
8. Write a dictionary comprehension to **square numbers**.
9. Group words by their first letter using a dictionary.
10. Create a **nested dictionary** and access/update its values.

========================================================================LISTS===========================================================================================


a=[1,2,3,4,5]
sum=0
for i in a:
    sum+=i
print(sum)
   
a=[1,2,2,2,3,1,4,5,6,7,7]
seen=set()
res=[]
for i in a:
    if i not in seen:
        seen.add(i)
        res.append(i)
print(res)
   
             
def bubble_sort(arr):
    n = len(arr)
    # Traverse through all array elements
    for i in range(n):
        # Last i elements are already in place
        for j in range(0, n - i - 1):
            # Swap if the element is greater than the next element
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

# Example usage
a = [5, 3, 8, 6, 2, 7, 4, 1]
bubble_sort(a)
print(a)


a=[12,1,2,444,3,4,999]
max1=max2=float('-inf')
for i in a:
    if i>max1:
        max2=max1
        max1=i
    if i>max2 and i!=max1:
        max2=i
print(max2)
        
a=[1,2,3,4]
b=[7,8,9]
c=(a+ b)
print(c)

a=[1,2,3,2,1]
if a==a[::-1]:
    print("SS")
else:
    print("NO")




def rotate_list_right(a, k):
    n = len(a)
    k = k % n  # Handle k > n
    a[:] = a[-k:] + a[:-k]  # In-place modification
    return a

# Example
a = [1, 2, 3, 4, 5]
rotate_list_right(a, 2)
print("Rotated list (right by 2):", a)



a=[1,2,3]
b=[2,3,4]
print(list(set(a) & set(b)))

a=[1,2,3,4,5,6,7,8,9]
o_c=e_c=0
for i in a:
    if i%2==0:
        e_c+=1
    else:
        o_c+=1
print(o_c,e_c)


a=[1,2,3,4,5,6,7]
left=0
right=len(a)-1
while left<right:
    a[left],a[right]=a[right],a[left]
    left+=1
    right-=1
print(a)
 '''
import heapq
def sec(arr):
    max_heap=[-num for num in uni]
    heapq.heapify(max_heap)
    lar=-heapq.heappop(max_heap)
    
    
    