a="10101"
c=0
iteration=0
while iteration<2:
    l1=int(a[-1])
    l2=int(a[-2])
    sumi=l1+l2
    a=a[:-2]+str(sumi)
    if a==a[::-1]:
        c+=1
        print(f"SSSSS ,count= {c}")
    else:
        print("NOT found")
    iteration+=1



