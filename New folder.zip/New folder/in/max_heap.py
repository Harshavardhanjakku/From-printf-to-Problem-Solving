class MaxHeap:
    def __init__(self):
        self.heap = []  # The heap as a list

    def insert(self, val):
        # Step 1: Append new value at the end
        self.heap.append(val)
        index = len(self.heap) - 1
        print(f"Inserted {val} at index {index}")

        # Step 2: Recursively fix the heap property
        self._heapify_up_recursive(index)

    def _heapify_up_recursive(self, index):
        # Base case: If at root, stop
        if index == 0:
            return

        parent_index = (index - 1) // 2

        # If current value is greater than parent, swap and recurse
        if self.heap[index] > self.heap[parent_index]:
            print(f"Swapping {self.heap[index]} with parent {self.heap[parent_index]}")
            self.heap[index], self.heap[parent_index] = self.heap[parent_index], self.heap[index]
            self._heapify_up_recursive(parent_index)

    def display(self):
        print("MaxHeap as array:", self.heap)
