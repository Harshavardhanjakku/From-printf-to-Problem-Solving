'''
4 4
1 2 3 4
5 6 7 8
9 0 1 4
5 2 3 9

opt:
5 9 5 1
2 0 6 2
3 1 7 3
9 4 8 4
90 degree rotate '''


r,c=map(int,input().split())
mat=[]
for _ in range(r):
    mat.append(list(map(int, input().split())))
for i in range(r):
    for j in range(i+1,c):
        mat[i][j],mat[j][i]=mat[j][i],mat[i][j]
for i in range(r):
    l,h=0,c-1
    while l < h:
        mat[i][l],mat[i][h]=mat[i][h],mat[i][l]
        l+=1
        h-=1
for row in mat:
    print(*row)
