def max_subarray_sum(nums):
    max_sum = float('-inf')  # Initialize to smallest possible value
    current_sum = 0          # Holds current running sum

    for num in nums:
        current_sum = max(num, current_sum + num)
        max_sum = max(max_sum, current_sum)

    return max_sum



### ✅ 3. Move Zeroes to End (in-place)

def move_zeroes(nums):
    last_non_zero = 0  # index to place the next non-zero element

    for i in range(len(nums)):
        if nums[i] != 0:
            nums[last_non_zero], nums[i] = nums[i], nums[last_non_zero]
            last_non_zero += 1
    return nums

# Explanation:
# last_non_zero: tracks the index where the next non-zero should be placed
# For every non-zero element, swap it to the front and increment pointer

# Dry Run:
# Input: [0, 1, 0, 3, 12]
# Step-by-step:
# i=0: 0 => skip
# i=1: swap nums[0] with nums[1] => [1, 0, 0, 3, 12], last_non_zero=1
# i=2: 0 => skip
# i=3: swap nums[1] with nums[3] => [1, 3, 0, 0, 12], last_non_zero=2
# i=4: swap nums[2] with nums[4] => [1, 3, 12, 0, 0], last_non_zero=3


### ✅ 4. Leaders in Array

def find_leaders(nums):
    n = len(nums)
    max_from_right = nums[-1]  # Rightmost element is always a leader
    leaders = [max_from_right]

    for i in range(n - 2, -1, -1):
        if nums[i] > max_from_right:
            max_from_right = nums[i]
            leaders.append(max_from_right)

    return leaders[::-1]  # Reverse to maintain order

# Dry Run:
# Input: [16, 17, 4, 3, 5, 2]
# Start from right: max_from_right = 2
# i=4 (5>2) => leaders=[2,5]
# i=3 (3<5) => skip
# i=2 (4<5) => skip
# i=1 (17>5) => leaders=[2,5,17]
# i=0 (16<17) => skip
# Return reversed: [17, 5, 2]


### ✅ 5. Rotate Array by k Places (Right)

def rotate_array(nums, k):
    n = len(nums)
    k %= n  # Handle k > n
    nums[:] = nums[-k:] + nums[:-k]
    return nums

# Dry Run:
# Input: [1,2,3,4,5,6,7], k=3
# After rotation: [5,6,7] + [1,2,3,4] = [5,6,7,1,2,3,4]


### ✅ 6. Longest Substring Without Repeating Characters

def longest_unique_substring(s):
    seen = {}
    start = max_len = 0

    for i, char in enumerate(s):
        if char in seen and seen[char] >= start:
            start = seen[char] + 1
        seen[char] = i
        max_len = max(max_len, i - start + 1)

    return max_len

# Dry Run:
# Input: "abcabcbb"
# i=0: a, max_len=1
# i=1: b, max_len=2
# i=2: c, max_len=3
# i=3: a found again, move start to 1
# Continue => Final max_len = 3


### ✅ 7. Check if Strings Are Anagrams

from collections import Counter

def is_anagram(s, t):
    return Counter(s) == Counter(t)

# Dry Run:
# s = "listen", t = "silent"
# Counter(s) => {'l':1,'i':1,'s':1,'t':1,'e':1,'n':1}
# Counter(t) => Same => return True


### ✅ 8. Longest Common Prefix

def longest_common_prefix(strs):
    if not strs:
        return ""

    prefix = strs[0]
    for s in strs[1:]:
        while not s.startswith(prefix):
            prefix = prefix[:-1]
            if prefix == "":
                return ""
    return prefix

# Dry Run:
# Input: ["flower","flow","flight"]
# prefix = "flower" => reduce step-by-step => "flo" => "fl" ✅


### ✅ 9. Trapping Rain Water

def trap(height):
    if not height:
        return 0

    n = len(height)
    left, right = 0, n - 1
    left_max = right_max = 0
    water = 0

    while left < right:
        if height[left] < height[right]:
            if height[left] >= left_max:
                left_max = height[left]
            else:
                water += left_max - height[left]
            left += 1
        else:
            if height[right] >= right_max:
                right_max = height[right]
            else:
                water += right_max - height[right]
            right -= 1

    return water

# Dry Run:
# Input: [0,1,0,2,1,0,1,3,2,1,2,1]
# Total trapped water = 6


### ✅ 10. Majority Element (Moore’s Voting)

def majority_element(nums):
    count = candidate = 0

    for num in nums:
        if count == 0:
            candidate = num
        count += (1 if num == candidate else -1)

    return candidate

# Dry Run:
# Input: [3,2,3]
# count=0 → pick 3, count=1 → 2!=3 => count=0 → pick 3 again → count=1
# Final candidate = 3

### ✅ 11. Search in Rotated Sorted Array

def search_rotated_array(nums, target):
    left, right = 0, len(nums) - 1

    while left <= right:
        mid = (left + right) // 2
        if nums[mid] == target:
            return mid  # Target found

        if nums[left] <= nums[mid]:  # Left half is sorted
            if nums[left] <= target < nums[mid]:
                right = mid - 1  # Target is in the left half
            else:
                left = mid + 1  # Target is in the right half
        else:  # Right half is sorted
            if nums[mid] < target <= nums[right]:
                left = mid + 1
            else:
                right = mid - 1

    return -1  # Target not found


### ✅ 12. Find Peak Element

def find_peak(nums):
    left, right = 0, len(nums) - 1

    while left < right:
        mid = (left + right) // 2
        if nums[mid] > nums[mid + 1]:
            right = mid  # Peak is on the left including mid
        else:
            left = mid + 1  # Peak is on the right

    return left  # or right (they're equal now)


### ✅ 13. Kth Largest Element using Heap

import heapq

def find_kth_largest(nums, k):
    return heapq.nlargest(k, nums)[-1]  # Get k largest and return the kth


### ✅ 14. Reverse Linked List

class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def reverse_list(head):
    prev = None
    current = head

    while current:
        next_node = current.next  # Save next node
        current.next = prev  # Reverse pointer
        prev = current  # Move prev forward
        current = next_node  # Move current forward

    return prev  # New head of reversed list


### ✅ 15. Detect Cycle in Linked List (Floyd’s Cycle Detection)

def has_cycle(head):
    slow = fast = head

    while fast and fast.next:
        slow = slow.next  # Move one step
        fast = fast.next.next  # Move two steps
        if slow == fast:
            return True  # Cycle detected

    return False  # No cycle


### ✅ 16. Merge Two Sorted Linked Lists

def merge_two_lists(l1, l2):
    dummy = ListNode(-1)  # Dummy node to simplify logic
    tail = dummy

    while l1 and l2:
        if l1.val < l2.val:
            tail.next = l1
            l1 = l1.next
        else:
            tail.next = l2
            l2 = l2.next
        tail = tail.next

    tail.next = l1 if l1 else l2  # Attach remaining part
    return dummy.next


### ✅ 17. Find Middle of Linked List

def find_middle(head):
    slow = fast = head

    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next

    return slow  # Middle node


### ✅ 18. Valid Parentheses

def is_valid_parentheses(s):
    stack = []
    mapping = {')': '(', '}': '{', ']': '['}

    for char in s:
        if char in mapping:
            top = stack.pop() if stack else '#'  # Pop or dummy if empty
            if mapping[char] != top:
                return False  # Mismatched
        else:
            stack.append(char)  # Push opening bracket

    return not stack  # True if stack is empty


''''

### ✅ 3. Move Zeroes to End (in-place)

def move_zeroes(nums):
    last_non_zero = 0  # This index tells where the next non-zero element should be placed

    for i in range(len(nums)):
        if nums[i] != 0:  # If the current element is non-zero
            # Swap the current non-zero element with the element at last_non_zero index
            nums[last_non_zero], nums[i] = nums[i], nums[last_non_zero]
            last_non_zero += 1  # Move the index forward for next non-zero
    return nums  # Modified list with all zeroes moved to the end

# Dry Run:
# Input: [0, 1, 0, 3, 12]
# Step-by-step:
# i=0: 0 => skip
# i=1: swap nums[0] with nums[1] => [1, 0, 0, 3, 12], last_non_zero=1
# i=2: 0 => skip
# i=3: swap nums[1] with nums[3] => [1, 3, 0, 0, 12], last_non_zero=2
# i=4: swap nums[2] with nums[4] => [1, 3, 12, 0, 0], last_non_zero=3


### ✅ 4. Leaders in Array

def find_leaders(nums):
    n = len(nums)
    max_from_right = nums[-1]  # Rightmost element is always a leader
    leaders = [max_from_right]  # Initialize leaders list with last element

    # Traverse from second last to the first element
    for i in range(n - 2, -1, -1):
        if nums[i] > max_from_right:  # If current element is greater than max so far from the right
            max_from_right = nums[i]  # Update max_from_right
            leaders.append(max_from_right)  # Append this element to leaders list

    return leaders[::-1]  # Reverse to maintain original array order

# Dry Run:
# Input: [16, 17, 4, 3, 5, 2]
# Start from right: max_from_right = 2
# i=4 (5>2) => leaders=[2,5]
# i=3 (3<5) => skip
# i=2 (4<5) => skip
# i=1 (17>5) => leaders=[2,5,17]
# i=0 (16<17) => skip
# Return reversed: [17, 5, 2]


### ✅ 5. Rotate Array by k Places (Right)

def rotate_array(nums, k):
    n = len(nums)
    k %= n  # Take modulus in case k > n, rotate only necessary steps
    # Slice and concatenate: last k elements + rest
    nums[:] = nums[-k:] + nums[:-k]  # In-place update
    return nums

# Dry Run:
# Input: [1,2,3,4,5,6,7], k=3
# After rotation: [5,6,7] + [1,2,3,4] = [5,6,7,1,2,3,4]


### ✅ 6. Longest Substring Without Repeating Characters

def longest_unique_substring(s):
    seen = {}  # Dictionary to store the last seen index of characters
    start = max_len = 0  # Start of current substring, max_len tracks the longest found

    for i, char in enumerate(s):  # Loop through each character with index
        # If the character is already seen and is part of the current substring
        if char in seen and seen[char] >= start:
            start = seen[char] + 1  # Move start to the right of previous occurrence
        seen[char] = i  # Update last seen index
        max_len = max(max_len, i - start + 1)  # Update max_len if needed

    return max_len  # Return the length of the longest unique substring

# Dry Run:
# Input: "abcabcbb"
# i=0: a, max_len=1
# i=1: b, max_len=2
# i=2: c, max_len=3
# i=3: a found again, move start to 1
# Continue => Final max_len = 3


### ✅ 7. Check if Strings Are Anagrams

from collections import Counter  # Importing Counter to count characters in strings

def is_anagram(s, t):
    return Counter(s) == Counter(t)  # Compare frequency of characters in both strings

# Dry Run:
# s = "listen", t = "silent"
# Counter(s) => {'l':1,'i':1,'s':1,'t':1,'e':1,'n':1}
# Counter(t) => Same => return True


### ✅ 8. Longest Common Prefix

def longest_common_prefix(strs):
    if not strs:
        return ""  # Return empty string if input list is empty

    prefix = strs[0]  # Start with the first string as prefix
    for s in strs[1:]:  # Loop through the rest
        while not s.startswith(prefix):  # Reduce prefix until match is found
            prefix = prefix[:-1]  # Trim the last character from prefix
            if prefix == "":
                return ""  # If prefix becomes empty, no common prefix
    return prefix  # Final common prefix

# Dry Run:
# Input: ["flower","flow","flight"]
# prefix = "flower" => reduce step-by-step => "flo" => "fl" ✅


### ✅ 9. Trapping Rain Water

def trap(height):
    if not height:
        return 0  # Edge case: empty array

    n = len(height)
    left, right = 0, n - 1  # Two pointers
    left_max = right_max = 0  # Track max on both sides
    water = 0  # Total water trapped

    while left < right:
        if height[left] < height[right]:
            if height[left] >= left_max:
                left_max = height[left]  # Update max height seen so far from left
            else:
                water += left_max - height[left]  # Water trapped at this point
            left += 1
        else:
            if height[right] >= right_max:
                right_max = height[right]  # Update max height seen so far from right
            else:
                water += right_max - height[right]  # Water trapped at this point
            right -= 1

    return water  # Return total trapped water

# Dry Run:
# Input: [0,1,0,2,1,0,1,3,2,1,2,1]
# Total trapped water = 6


### ✅ 10. Majority Element (Moore’s Voting)

def majority_element(nums):
    count = candidate = 0  # Initialize count and candidate

    for num in nums:
        if count == 0:  # If count is zero, choose new candidate
            candidate = num
        # Increment or decrement count based on current element
        count += (1 if num == candidate else -1)

    return candidate  # Final candidate is the majority element

# Dry Run:
# Input: [3,2,3]
# count=0 → pick 3, count=1 → 2!=3 => count=0 → pick 3 again → count=1
# Final candidate = 3


''''