# Depth-First Search (DFS) using Recursion

def dfs(graph, node, visited):
    # Step 1: Mark the current node as visited
    visited.add(node)
    
    # Step 2: Print or process the current node
    print(node, end=' ')
    
    # Step 3: Visit all unvisited neighbors
    for neighbor in graph[node]:
        if neighbor not in visited:
            dfs(graph, neighbor, visited)  # Recursive call to go deeper

# ------------------------------
# Sample undirected graph (Adjacency List)
graph = {
    0: [1, 2],
    1: [0, 3],
    2: [0],
    3: [1]
}

# Create an empty set to keep track of visited nodes
visited = set()

# Starting DFS from node 0
print("DFS Traversal:")
dfs(graph, 0, visited)
