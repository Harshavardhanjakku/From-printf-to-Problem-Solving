'''
| #  | Question                                                                 |
| -- | ------------------------------------------------------------------------ |
| 1  | Reverse a string without using `[::-1]`.                                 |
| 2  | Check whether a string is a palindrome (e.g., “madam”).                  |
| 3  | Count vowels, consonants, digits, and special characters in a string.    |
| 4  | Remove all duplicate characters from a string.                           |
| 5  | Convert a string to title case (first letter capitalized for each word). |
| 6  | Find the frequency of each character in a string.                        |
| 7  | Replace all spaces in a string with hyphens (`-`).                       |
| 8  | Find the longest word in a sentence.                                     |
| 9  | Count occurrences of a specific word in a string.                        |
| 10 | Check if two strings are anagrams (e.g., “listen” and “silent”).
    11.LCMA ND GCD|

a=input()
print(a[::-1])

a=input(" ")
if a[::-1]==a:
    print("YES")
else:
    print("NO")


a=input(" ")
v="AEIOUaeiou"
vc=0
cc=0
sc=0
for i in a:
    if i in v:
        vc+=1
    elif i.isalpha():
        cc+=1
    else:
        sc+=1
print(vc)
print(cc)
print(sc)


a=input("Enter:")
seen=[]
res=""
for i in a:
    if i not in seen:
        seen.append(i)
        res+=i      
print(res)

a=input("Enter: ")
print(a.title())


a=input("Enter: ")
b=input("ENter: ")
if sorted(a)==sorted(b):
    print("S")
else:
    print("NO")
    

a=input("ENter: ")
words=a.split()
l=words[0]
for i in words:
    if len(i)>len(l):
        l=i
print(l)

a=input("Enter :")
print(a.replace(' ','-'))

a=input("Enter")
freq = {}
for i in a:
    if i in freq:
        freq[i] += 1
    else:
        freq[i] = 1
        
for k, v in freq.items():
    print(f"{k} → {v}")



a=input("Enter: ")
w=a.split()
freq=0
ss=input()
for i in w:
    if i.lower()==ss.lower():
        freq+=1
print(freq)



def reverse_string(s):
    reversed_str = ''
    for char in s:
        return ''.join(reversed(s))
a = input("Enter a string: ")
print("Reversed string:", reverse_string(a))


def gcd(a,b):
    while b:
        a,b=b,a%b
    return a
def lcm(a,b):
    return (a*b)//gcd(a,b)
a,b=list(map(int,input().split()))
print(gcd(a,b),end=" ")
print(lcm(a,b))

'''
def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def lcm(a, b):
    return (a * b) // gcd(a, b)

# 🐣 Take input in one line like: 10 20
a,b=list(map(int,input().split()))
print(gcd(a,b))
print(lcm(a,b))
print(gcd(a,b) , lcm(a,b))



    