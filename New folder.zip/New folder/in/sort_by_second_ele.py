'''
Given a 2d array (take input)like input is 3,8
1,2
2,7
6,3
sort it based on 2nd element
dont use sort or sorted ,use bubble sort

'''
a,b=map(int,input().split())
arr=[]
for _ in range(a):
    ro=list(map(int,input().split()))
    arr.append(ro)
for i in range(a-1):
    for j in range(a-i-1):
        if arr[j][1]>arr[j+1][1]:
            arr[j+1],arr[j]=arr[j],arr[j+1]
for ro in arr:
    print(ro[0],ro[1])
            





























