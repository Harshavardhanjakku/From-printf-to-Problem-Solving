class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None
def inorder(root):
    if root:#checks if node exixsts
        inorder(root.left)
        print(root.data,end=' ')
        inorder(root.right)
def post(root):
    if root:
        post(root.left)
        post(root.right)
        print(root.data,end=' ')
def pre(root):
    if root:
        print(root.data,end=' ')
        pre(root.left)
        pre(root.right)
    
root=Node(1)
root.left=Node(2)
root.right=Node(3)
root.left.left=Node(4)
root.left.right=Node(5)
inorder(root)
print("POSTORDER BELOW")
post(root)
print("PRE BELOW")
pre(root)