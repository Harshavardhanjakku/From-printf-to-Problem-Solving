'''
ip:
4 4
1 2 3 4
5 6 7 8
9 0 1 4
5 2 3 9

output:
1 5 9 5
2 6 0 2
3 7 1 3
4 8 4 9
 Take input , Transpose should be printed
 '''


ro,col=map(int,input().split())
mat=[]
for _ in range(ro):
    row=list(map(int,input().split()))
    mat.append(row)
for i in range(col):
    for j in range(ro):
        print(mat[j][i],end=" ")
    print()
