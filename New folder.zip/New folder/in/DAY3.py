#DAY 3
'''
n=int(input())
for  i in range(n+1):
    print(i)

i=1
while i<=n:
    print(i)
    i+=1
    
for i in range(0,101,2):
    print(i)
    
n=int(input())
s=0
for i in range(n+1):
    s+=i
print(s)

n=int(input())
for i in range(1,11):
    print(f"{n} X {i} = {n*i}")


n=int(input())
f=1
for i in range(1,n+1):
    f=f*(i)

a=123
print(int(str(a)[::-1]))
'''

