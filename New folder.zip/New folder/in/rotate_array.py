'''
a=list(map(int,input().split()))
k=int(input())
k=k%len(a)
a[:]=a[-k:]+a[:-k]
print(*a)
'''

a=list(map(int, input().split()))
k=int(input())
k=k%len(a)
i, j = 0, len(a) - 1
while i < j:
    a[i], a[j] = a[j], a[i]
    i += 1
    j -= 1
i,j=0,k-1
while i<j:
    a[i],a[j]=a[j],a[i]
    i+=1
    j-=1
i,j=k,len(a)-1
while i<j:
    a[i],a[j]=a[j],a[i]
    i+=1
    j-=1
print(*a)
