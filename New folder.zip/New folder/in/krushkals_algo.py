# Step 1: Disjoint Set (Union-Find) with path compression
class DisjointSet:
    def __init__(self, n):
        # Every node is its own parent initially
        self.parent = [i for i in range(n)]
    
    def find(self, node):
        # Find parent (with path compression)
        if self.parent[node] != node:
            self.parent[node] = self.find(self.parent[node])  # compress path
        return self.parent[node]
    
    def union(self, u, v):
        # Union two sets by connecting parents
        pu = self.find(u)
        pv = self.find(v)
        if pu == pv:
            return False  # They are already connected → cycle
        self.parent[pu] = pv  # Connect one root to another
        return True

# Step 2: Kruskal's Algorithm
def kruskals_algorithm(n, edges):
    """
    n = number of vertices (labeled 0 to n-1)
    edges = list of (weight, u, v)
    """
    # Sort edges based on weights
    edges.sort()  # O(E log E)
    
    ds = DisjointSet(n)
    mst_weight = 0
    mst_edges = []

    for weight, u, v in edges:
        # If u and v are in different sets, add this edge to MST
        if ds.union(u, v):
            mst_weight += weight
            mst_edges.append((u, v, weight))
            print(f"Edge ({u}-{v}) with weight {weight} added to MST.")
        else:
            print(f"Edge ({u}-{v}) with weight {weight} creates a cycle. Skipped.")
    
    print("\n Minimum Spanning Tree Complete.")
    print("Edges in MST:", mst_edges)
    print("Total weight of MST:", mst_weight)
    return mst_weight
# Graph with 4 nodes: 0, 1, 2, 3
edges = [
    (1, 0, 1),  # weight, u, v
    (3, 0, 2),
    (4, 1, 2),
    (2, 1, 3),
    (5, 2, 3)
]

n = 4  # number of vertices
kruskals_algorithm(n, edges)