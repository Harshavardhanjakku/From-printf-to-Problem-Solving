def majority(a):
    seen={}
    c=0
    for i in a:
        if i in seen:
            seen[i]+=1
        else:
            seen[i]=1
        if seen[i]>len(a)//2:
            return i
a = [2,2,1,2,2,3,2]
print(majority(a))  # Output: 2


        

