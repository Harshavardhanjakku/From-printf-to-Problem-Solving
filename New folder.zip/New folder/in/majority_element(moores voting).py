def majo(nums):
    c=0
    candidate=None
    for i in nums:
        if c==0:
            candidate=i
        c+=(1 if i==candidate else -1)
    return candidate
nums=list(map(int,input().split()))
print(majo(nums))