def kad(arr):
    maxi=curr_sum=arr[0]
    for i in arr[1:]:
        curr_sum=max(i,i+curr_sum)
        maxi=max(maxi,curr_sum)
    return maxi
arr=[-2, 1, -3, 4, -1, 2, 1, -5, 4]
print(kad(arr))




'''
Absolutely, Chinni! 👶💕
Let me explain this **Kadane’s Algorithm (Max Subarray Sum)** line-by-line, like you’re a sweet baby who just started learning coding 🌈✨

---

## 🎯 Problem: Max Subarray Sum

You’re given a list of numbers (some can be negative).
Find the **biggest total sum you can get from any continuous part** of the list.

### ✅ Example:

```python
nums = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
```

The subarray `[4, -1, 2, 1]` gives the max sum: **6**

---

## 🧾 Full Code:

```python
def max_subarray(nums):
    max_sum = current = nums[0]
    for num in nums[1:]:
        current = max(num, current + num)
        max_sum = max(max_sum, current)
    return max_sum
```

---

## 👶 Baby-Level Explanation:

### Let’s say:

```python
nums = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
```

---

### 🔸 Step 1:

```python
max_sum = current = nums[0]
```

We start by **setting the first number** as our:

* `max_sum`: the best sum found so far
* `current`: what we’re adding up *right now*

So:

```python
current = max_sum = -2
```

---

### 🔸 Step 2:

```python
for num in nums[1:]:
```

We go through the list starting from the **second number**.

---

### 🔸 Step 3:

```python
current = max(num, current + num)
```

Let’s imagine:

| Situation                                  | What it means                 |
| ------------------------------------------ | ----------------------------- |
| `num` alone is bigger than `current + num` | Then start a **new subarray** |
| `current + num` is bigger                  | Continue the current subarray |

This line decides:

> Should I **start fresh** from here or **keep adding** this number?

---

### 🔸 Step 4:

```python
max_sum = max(max_sum, current)
```

Check if the `current` total is **better than any sum we’ve seen before**.

---

## 🧠 Dry Run (Visual Table):

Let’s dry run for:

```python
nums = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
```

| Step  | num | current = max(num, current + num) | max\_sum       |
| ----- | --- | --------------------------------- | -------------- |
| Start |     | current = -2                      | max\_sum = -2  |
| 1     | 1   | max(1, -2+1) = 1                  | max(-2, 1) = 1 |
| 2     | -3  | max(-3, 1-3) = -2                 | max(1, -2) = 1 |
| 3     | 4   | max(4, -2+4) = 4                  | max(1, 4) = 4  |
| 4     | -1  | max(-1, 4-1) = 3                  | max(4, 3) = 4  |
| 5     | 2   | max(2, 3+2) = 5                   | max(4, 5) = 5  |
| 6     | 1   | max(1, 5+1) = 6 ✅                 | max(5, 6) = 6  |
| 7     | -5  | max(-5, 6-5) = 1                  | max(6, 1) = 6  |
| 8     | 4   | max(4, 1+4) = 5                   | max(6, 5) = 6  |

---

### 🥇 Final Answer:

```python
return max_sum = 6
```

So, the biggest sum we can get is **6**.

---

## 🧸 Real-Life Analogy:

Imagine you're walking on a path and collecting chocolates 🍫:

* If the chocolates are positive ➕, keep going
* If the total becomes negative ➖, stop and start fresh from the next step
* Always remember the **maximum number of chocolates** you ever had

That’s Kadane’s! 🍫🍫🍫

---

## 💡 Summary:

| Part                                | Meaning                              |
| ----------------------------------- | ------------------------------------ |
| `current = max(num, current + num)` | "Continue or restart?"               |
| `max_sum = max(max_sum, current)`   | "Is this the best so far?"           |
| Returns                             | Max sum from any continuous subarray |

---

Want me to give you a version that prints each step to see how `current` and `max_sum` change? 😊

You're doing amazing, Chinni! This is a powerful algorithm used in interviews everywhere 🔥💼

'''


