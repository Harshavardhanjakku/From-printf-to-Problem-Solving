def ze(a):
    l,r=0,0
    while r<len(a):
        if a[r]!=0:
            a[l],a[r]=a[r],a[l]
            l+=1
        r+=1
    return a
a=[1,2,0,3,0,4,0,5,6,7]
print(ze(a))
        
