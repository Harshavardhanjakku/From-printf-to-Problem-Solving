a=[1,2,3]
res=[]
for i in range(len(a)):
    for j in range(i,len(a)):
        res.append(a[i:j+1])
print(res)