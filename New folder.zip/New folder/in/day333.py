'''
| #  | Question       DAY 3                                         |
| -- | ------------------------------------------------------- |
| 1  | Print numbers from 1 to N using both `for` and `while`. |
| 2  | Print even numbers from 1 to 100.                       |
| 3  | Find the sum of first N natural numbers.                |
| 4  | Print the multiplication table of a number.             |
| 5  | Find the factorial of a number.                         |
| 6  | Print the reverse of a given number (e.g., 123 → 321).  |
| 7  | Count the digits in a given number.                     |
| 8  | Check whether a number is a palindrome.                 |
| 9  | Generate the Fibonacci sequence up to N terms.          |
| 10 | Print all prime numbers between 1 and N.                |

'''
'''
n=int(input())
i=1
for i in range(n):
    print(i)
while (i<=n):
    print(i)
    i+=1
  
n=int(input())   
fact=1
for i in range(1,n+1):
    fact=fact*i
print(fact)


def rev(n):
    rev=0
    while n>0:
        d=n%10
        rev=rev*10+d
        n=n//10
    return rev
n=int(input())
print(rev(n))


n=int(input())
c=0
while n>0:
    c+=1
    n=n//10
print(c)


def p(n):
    if n<=1:
        return False
    for i in range(2,int(n**0.5)+1):
        if n%i==0:
            return False
    return True
n=int(input())
print(p(n))
'''
def fib(n):
    a=0
    b=1
    for i in range(n):
        print(a)
        a,b=b,a+b
n=int(input())
fib(n)
