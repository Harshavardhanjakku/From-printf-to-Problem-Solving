a="Shreya"
a=list(a)
left=0
right=len(a)-1
v="AEIOUaeiou"
while left<right:
    if a[left] not in v:
        left+=1
    elif a[right] not in v:
        right-=1
    else:
        a[left],a[right]=a[right],a[left]
        left+=1
        right-=1
print(''.join(a))
        
        