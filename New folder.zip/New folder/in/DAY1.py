'''1.
a=int(input())
b=int(input())
print(a+b,a-b,a*b,a/b,a//b)

r=2
print(3.14*r*r)

age=int(input())
name=input()
print(f"My name is {name} and age is {age}")

c=0
print(c*(9//5)+32)

a=2
b=10
a=a+b
b=a-b
a=a-b
print(a,b)
'''
a=int(input())
b=int(input())
print("True" if a==b else "False")