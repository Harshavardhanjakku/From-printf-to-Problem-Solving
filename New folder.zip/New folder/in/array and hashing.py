# Contains Duplicate
# ✅ Problem: Check if any value appears at least twice in the array.

def containsDuplicate(nums):
    seen = set()
    for num in nums:
        if num in seen:
            return True
        seen.add(num)
    return False

# 👶 Explanation:
# - Create an empty set `seen`.
# - Loop through each number in array:
#     - If number already in `seen`, return True (duplicate found)
#     - Otherwise, add it to the set.
# - If loop completes with no duplicates, return False.

# Dry Run:
# nums = [1, 2, 3, 1]
# seen = {}
# -> 1 added
# -> 2 added
# -> 3 added
# -> 1 already in seen => return True ✅


# Valid Anagram
# ✅ Problem: Check if two strings are anagrams.

def isAnagram(s, t):
    return sorted(s) == sorted(t)

# 👶 Explanation:
# - Sort both strings.
# - If their sorted versions are equal, they are anagrams.

# Dry Run:
# s = "listen", t = "silent"
# sorted(s) = ['e','i','l','n','s','t']
# sorted(t) = ['e','i','l','n','s','t'] ✅


# Two Sum
# ✅ Problem: Return indices of two numbers that add up to target.

def twoSum(nums, target):
    hashmap = {}
    for i, num in enumerate(nums):
        diff = target - num
        if diff in hashmap:
            return [hashmap[diff], i]
        hashmap[num] = i

# 👶 Explanation:
# - Create a dictionary `hashmap` to store value:index.
# - Loop through each number with index.
# - Check if (target - num) exists in hashmap:
#     - If yes, return its index and current index.
#     - Else, store num with index in hashmap.

# Dry Run:
# nums = [2, 7, 11, 15], target = 9
# hashmap = {}
# -> i=0, num=2, diff=7 (not in hashmap)
# -> i=1, num=7, diff=2 (2 in hashmap) => return [0,1] ✅


# Group Anagrams
# ✅ Problem: Group words that are anagrams.
from collections import defaultdict

def groupAnagrams(strs):
    hashmap = defaultdict(list)
    for word in strs:
        key = tuple(sorted(word))
        hashmap[key].append(word)
    return list(hashmap.values())

# 👶 Explanation:
# - Use a dictionary where key is sorted word.
# - For each word, sort it and use as key, append to list.
# - Return grouped anagram lists.

# Dry Run:
# strs = ["eat", "tea", "tan", "ate", "nat", "bat"]
# hashmap = {('a','e','t'):["eat","tea","ate"], ('a','n','t'):["tan","nat"], ('a','b','t'):["bat"]} ✅


# Top K Frequent Elements
# ✅ Problem: Return k most frequent elements.
from collections import Counter

def topKFrequent(nums, k):
    count = Counter(nums)
    return [item for item, freq in count.most_common(k)]

# 👶 Explanation:
# - Use Counter to count frequency.
# - Use most_common(k) to get top k frequent items.

# Dry Run:
# nums = [1,1,1,2,2,3], k = 2
# count = {1:3, 2:2, 3:1}
# return [1,2] ✅


# Encode and Decode Strings
# ✅ Problem: Encode a list of strings and decode it back.

def encode(strs):
    return ''.join(f'{len(s)}#{s}' for s in strs)

def decode(s):
    i = 0
    res = []
    while i < len(s):
        j = i
        while s[j] != '#':
            j += 1
        length = int(s[i:j])
        res.append(s[j+1:j+1+length])
        i = j + 1 + length
    return res

# 👶 Explanation:
# - Encode: prefix each string with its length and a '#'.
# - Decode: parse number before '#', extract string of that length.

# Dry Run:
# encode(["lint", "code"])
# => "4#lint4#code"
# decode("4#lint4#code") => ["lint", "code"] ✅


# Product of Array Except Self
# ✅ Problem: Return array where each element is product of all except itself.

def productExceptSelf(nums):
    res = [1] * len(nums)
    prefix = 1
    for i in range(len(nums)):
        res[i] = prefix
        prefix *= nums[i]
    postfix = 1
    for i in range(len(nums)-1, -1, -1):
        res[i] *= postfix
        postfix *= nums[i]
    return res

# 👶 Explanation:
# - Prefix pass: store product of all before i.
# - Postfix pass: multiply product of all after i.

# Dry Run:
# nums = [1,2,3,4]
# prefix pass -> [1,1,2,6]
# postfix pass -> [24,12,8,6] ✅


# Valid Sudoku
# ✅ Problem: Check if 9x9 Sudoku board is valid.

def isValidSudoku(board):
    rows = [set() for _ in range(9)]
    cols = [set() for _ in range(9)]
    boxes = [set() for _ in range(9)]

    for r in range(9):
        for c in range(9):
            val = board[r][c]
            if val == '.':
                continue
            if val in rows[r] or val in cols[c] or val in boxes[(r//3)*3 + c//3]:
                return False
            rows[r].add(val)
            cols[c].add(val)
            boxes[(r//3)*3 + c//3].add(val)
    return True

# 👶 Explanation:
# - Use sets for rows, cols, boxes.
# - Check if value already seen in any of those.
# - Box index = (r//3)*3 + (c//3)

# Dry Run: Check top left 3x3 box values for duplicates ✅


# Longest Consecutive Sequence
# ✅ Problem: Return length of longest consecutive sequence.

def longestConsecutive(nums):
    num_set = set(nums)
    longest = 0

    for num in num_set:
        if num - 1 not in num_set:
            length = 0
            while num + length in num_set:
                length += 1
            longest = max(longest, length)
    return longest

# 👶 Explanation:
# - Convert to set for O(1) lookup.
# - Only start from num if num-1 is not in set (start of streak).
# - Expand streak and count.

# Dry Run:
# nums = [100, 4, 200, 1, 3, 2]
# set = {1,2,3,4,100,200}
# Start at 1 → 1,2,3,4 => length = 4 ✅



## Problem: 3Sum

You are given an integer array `nums`, return all the triplets `[nums[i], nums[j], nums[k]]` such that:

* `i != j`, `i != k`, and `j != k`
* `nums[i] + nums[j] + nums[k] == 0`

### 🔹 Example Input:

```python
nums = [-1, 0, 1, 2, -1, -4]
```

### ✅ Output:

```python
[[-1, -1, 2], [-1, 0, 1]]
```

---

### ✅ Final Code:

```python
def threeSum(nums):
    res = []
    nums.sort()
    for i in range(len(nums)):
        if i > 0 and nums[i] == nums[i-1]:
            continue
        l, r = i+1, len(nums)-1
        while l < r:
            total = nums[i] + nums[l] + nums[r]
            if total < 0:
                l += 1
            elif total > 0:
                r -= 1
            else:
                res.append([nums[i], nums[l], nums[r]])
                while l < r and nums[l] == nums[l+1]:
                    l += 1
                while l < r and nums[r] == nums[r-1]:
                    r -= 1
                l += 1
                r -= 1
    return res
```

---

### 🧠 Line-by-Line Baby Explanation:

#### Step 1: Sort the array first

```python
nums.sort()
```

🔸 This helps to avoid duplicates and use two-pointer technique easily.

#### Step 2: Loop through each element

```python
for i in range(len(nums)):
```

🔸 Treat each number as a potential first element in the triplet.

#### Step 3: Skip duplicates

```python
if i > 0 and nums[i] == nums[i-1]:
    continue
```

🔸 If current number is same as the previous, skip it to avoid duplicate triplets.

#### Step 4: Initialize two pointers

```python
l, r = i+1, len(nums)-1
```

🔸 `l` starts right after `i`, `r` starts from end of array.

#### Step 5: Two-pointer while loop

```python
while l < r:
```

🔸 As long as left is less than right, check the sum.

#### Step 6: Calculate the sum

```python
total = nums[i] + nums[l] + nums[r]
```

🔸 Add the three numbers.

#### Step 7: Compare the sum

```python
if total < 0:
    l += 1
elif total > 0:
    r -= 1
```

🔸 If sum is too small, move left to a bigger number.
🔸 If sum is too big, move right to a smaller number.

#### Step 8: If sum is 0, store it

```python
res.append([nums[i], nums[l], nums[r]])
```

🔸 Valid triplet found!

#### Step 9: Skip duplicates on both sides

```python
while l < r and nums[l] == nums[l+1]:
    l += 1
while l < r and nums[r] == nums[r-1]:
    r -= 1
```

🔸 Move past duplicates to avoid repeating the same result.

#### Step 10: Move both pointers inward

```python
l += 1
r -= 1
```

#### Final Step:

```python
return res
```

🔸 Return the list of all triplets.

---

### 🧪 Dry Run Example:

**Input:** `[-1, 0, 1, 2, -1, -4]`  → after sorting → `[-4, -1, -1, 0, 1, 2]`

**i = 0** (`-4`)  → total = `-4 + (-1) + 2 = -3` → move left forward

**i = 1** (`-1`)  → total = `-1 + (-1) + 2 = 0` ✅ triplet found

**Next:** check for duplicates and continue

Final result: `[[-1, -1, 2], [-1, 0, 1]]`

---

## Problem: Majority Element

You are given an array of size `n`. Find the majority element.
The majority element is the element that appears more than `n/2` times.

🔹 You may assume that the majority element always exists.

### 🔹 Example Input:

```python
nums = [2, 2, 1, 1, 1, 2, 2]
```

### ✅ Output:

```python
2
```

---

### ✅ Final Code:

```python
def majorityElement(nums):
    count = 0
    candidate = None

    for num in nums:
        if count == 0:
            candidate = num
        count += (1 if num == candidate else -1)

    return candidate
```

---

### 🧠 Line-by-Line Baby Explanation:

#### Step 1: Initialize count and candidate

```python
count = 0
candidate = None
```

🔸 We'll track a possible majority element (candidate) and how confident we are (count).

#### Step 2: Traverse through array

```python
for num in nums:
```

🔸 Go through each number in the array

#### Step 3: If count is 0, choose new candidate

```python
if count == 0:
    candidate = num
```

🔸 When count drops to 0, we reset the candidate.

#### Step 4: Adjust count

```python
count += (1 if num == candidate else -1)
```

🔸 Increase count if the number matches candidate, else decrease.

#### Final Step:

```python
return candidate
```

🔸 Return the majority element at the end.

---

### 🧪 Dry Run Example:

Input: `[2, 2, 1, 1, 1, 2, 2]`

* count = 0 → pick 2 → count = 1
* 2 again → count = 2
* 1 → count = 1
* 1 → count = 0
* 1 → pick 1 → count = 1
* 2 → count = 0
* 2 → pick 2 → count = 1

Final majority element = 2 ✅

---

## Problem: Best Time to Buy and Sell Stock

You are given an array `prices` where `prices[i]` is the price of a stock on the i-th day. Return the maximum profit you can achieve from **one transaction** (buy and sell one time).

🔹 If you cannot achieve any profit, return 0.

### 🔹 Example Input:

```python
prices = [7, 1, 5, 3, 6, 4]
```

### ✅ Output:

```python
5
```

---

### ✅ Final Code:

```python
def maxProfit(prices):
    min_price = float('inf')
    max_profit = 0

    for price in prices:
        if price < min_price:
            min_price = price
        elif price - min_price > max_profit:
            max_profit = price - min_price

    return max_profit
```

---

### 🧠 Line-by-Line Baby Explanation:

#### Step 1: Initialize variables

```python
min_price = float('inf')
max_profit = 0
```

🔸 Start with infinite as minimum so first price is definitely lower.
🔸 Keep track of max profit seen so far.

#### Step 2: Traverse prices

```python
for price in prices:
```

🔸 Go day by day.

#### Step 3: Update min price

```python
if price < min_price:
    min_price = price
```

🔸 Keep lowering the minimum buying price.

#### Step 4: Check profit

```python
elif price - min_price > max_profit:
    max_profit = price - min_price
```

🔸 If selling today gives a better profit, update max profit.

#### Final Step:

```python
return max_profit
```

🔸 Return the best profit you can make.

---

### 🧪 Dry Run Example:

Input: `[7, 1, 5, 3, 6, 4]`

* Buy at 1, sell at 6 → profit = 5 ✅
* Any other combo gives less profit.

✅ Final Answer: `5`

