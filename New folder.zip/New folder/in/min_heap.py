class MinHeap:
    def __init__(self):
        self.heap = []  # The heap will be stored as a list

    def insert(self, val):
        # Step 1: Append the value to the end
        self.heap.append(val)
        print(f"Inserted {val} at index {len(self.heap) - 1}")

        # Step 2: Heapify Up to maintain min heap property
        self._heapify_up(len(self.heap) - 1)

    def _heapify_up(self, index):
        # Get parent index
        parent_index = (index - 1) // 2

        # While we haven't reached root and heap property is violated
        while index > 0 and self.heap[index] < self.heap[parent_index]:
            print(f"Swapping {self.heap[index]} with parent {self.heap[parent_index]}")
            # Swap child and parent
            self.heap[index], self.heap[parent_index] = self.heap[parent_index], self.heap[index]
            # Move up one level
            index = parent_index
            parent_index = (index - 1) // 2

    def display(self):
        print("Current MinHeap as array:", self.heap)


#With RECURSION
        '''
class MinHeap:
    def __init__(self):
        self.heap = []  # The heap stored as a list

    def insert(self, val):
        # Step 1: Add the value at the end
        self.heap.append(val)
        index = len(self.heap) - 1
        print(f"Inserted {val} at index {index}")

        # Step 2: Recursively fix the heap property
        self._heapify_up_recursive(index)

    def _heapify_up_recursive(self, index):
        # Base case: If at root, return
        if index == 0:
            return

        parent_index = (index - 1) // 2

        # If current value is smaller than parent, swap and recurse
        if self.heap[index] < self.heap[parent_index]:
            print(f"Swapping {self.heap[index]} with parent {self.heap[parent_index]}")
            self.heap[index], self.heap[parent_index] = self.heap[parent_index], self.heap[index]
            # Recursive call to move up
            self._heapify_up_recursive(parent_index)

    def display(self):
        print("MinHeap as array:", self.heap)
'''
