def a_ex(a):
    n=len(a)
    res=[1]*n
    prefix=1
    for i in range(n):
        res[i]=prefix
        prefix=prefix*a[i]
    postfix=1
    for i in range(n-1,-1,-1):
        res[i]=res[i]*postfix
        postfix=postfix*a[i]
    return res
a=[1,2,3,4]
print(a_ex(a))