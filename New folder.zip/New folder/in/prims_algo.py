import heapq  # to use priority queue (min-heap)

def prims_algorithm(graph, start_node):
    # Step 1: Initialize a set to keep track of visited nodes
    visited = set()

    # Step 2: Use a min-heap to always pick the edge with the smallest weight
    # Format: (weight, current_node)
    min_heap = [(0, start_node)]  # Start with the starting node with 0 cost

    # Step 3: Variable to store total weight of the Minimum Spanning Tree (MST)
    total_weight = 0

    # Step 4: While there are still nodes to process
    while min_heap:
        # Step 4.1: Extract the edge with the smallest weight
        weight, current_node = heapq.heappop(min_heap)

        # Step 4.2: If we already visited this node, skip it (to avoid cycles)
        if current_node in visited:
            continue

        # Step 4.3: Otherwise, add this node to visited set
        visited.add(current_node)

        # Step 4.4: Add this edge's weight to total MST weight
        total_weight += weight
        print(f"Adding node {current_node} with edge weight {weight} to MST.")

        # Step 4.5: Explore all neighbors of this node
        for neighbor, edge_weight in graph[current_node]:
            # Step 4.6: If neighbor is not visited, add it to the heap for future processing
            if neighbor not in visited:
                heapq.heappush(min_heap, (edge_weight, neighbor))
                print(f" --> Adding edge ({current_node} → {neighbor}) with weight {edge_weight} to heap.")

    # Step 5: After the loop ends, return the total MST cost
    return total_weight

# Define the graph: adjacency list
# Format: node: [(neighbor, weight), ...]

graph = {
    0: [(1, 4), (2, 3)],
    1: [(0, 4), (2, 1)],
    2: [(0, 3), (1, 1)]
}

# Choose starting node
start = 0

# Run the algorithm
print("Running Prim's Algorithm...\n")
mst_cost = prims_algorithm(graph, start)

# Final Output
print(f"\n Total cost of Minimum Spanning Tree: {mst_cost}")

'''
     0
    / \
   1---2
Weights:
0-1 = 4, 0-2 = 3, 1-2 = 1
'''