def a_s_r(nums):
    b_p = 0  # break point counter
    n = len(nums)

    for i in range(n):
        if nums[i] > nums[(i+1) % n]:  # compare with next (circular)
            b_p += 1
            if b_p > 1:
                return False
    return True

nums = [3,4,5,1,2]
print(a_s_r(nums))  # True
