'''
#INCCREASING TRIANGLE
n=6
for i in range(n):
    for j in range(i+1):
        print('*',end=" ")
    print()

#DECRESING TRIANGLE
n=5
for i in range(n):
    for j in range(n-i):
        print('*',end=" ")
    print()

n=5
for i in range(n):
    for j in range(n-i):
        print(' ',end=" ")
    for j in range(i+1):
        print('*',end=" ")
    
    print()

n=5
for i in range(n):
    print('*'*n)

n=5
for i in range(n):
    for j in range(n-i):
        print(' ',end=' ')
    for j in range(i):
        print('*',end=' ')
    for j in range(i+1):
        print('*',end=' ')
    print()
'''
n=6
for i in range(n):
    for j in range(1,i+1):
        print(i,end=' ')
    print()