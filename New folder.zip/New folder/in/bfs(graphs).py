from collections import deque

def bfs(graph, start):
    # Step 1: Create a set to store visited nodes
    visited = set()
    
    # Step 2: Use a queue to store nodes to be explored
    queue = deque()
    queue.append(start)

    # Step 3: Loop until queue is empty
    while queue:
        # Pop the front element
        node = queue.popleft()

        # Process the node if not visited
        if node not in visited:
            print(node, end=' ')
            visited.add(node)

            # Add all unvisited neighbors to the queue
            for neighbor in graph[node]:
                if neighbor not in visited:
                    
                    queue.append(neighbor)
# Same graph
graph = {
    0: [1, 2],
    1: [0, 3],
    2: [0],
    3: [1]
}

print("\nBFS Traversal:")
bfs(graph, 0)
