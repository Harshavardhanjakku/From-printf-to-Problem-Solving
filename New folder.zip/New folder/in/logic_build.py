'''
#1.Print all even numbers from 1 to N
for i in range(1,11):
    if i%2==0:
        print(i)

===========================================================
#Check if a number is prime
def is_prime(n):
    for i in range(2,int(n**0.5)+1):
        if n%i==0:
            return False
    return True
n=13
print(is_prime(n))
===============================================================
#Prime numbers uptil a range given
def is_prime(n):
    for i in range(2,int(n**0.5)+1):
        if n%i==0:
            return False
    return True
n=int(input())
for i in range(2,n+1):
    if is_prime(i):
        print(i,end=" ")

================================================================

#Sum of digits of a number
a=1234
sum=0
while a>0:
    b=a%10 #gives last digit
    sum=sum+b %# adds that last digit to sum and addition operation
    a=a//10 #removes last digit so that now from 1234,we will send 123 and again the process continues till a>0
print(sum)
==================================================================

#Reverse of a Number
a=121
temp=a
rev=0
while a>0:
    d=a%10
    rev=rev*10+d
    a=a//10
print(rev)
#PALINDROME
if rev==temp:
    print("Palindrome")
else:
    print("NO")
  
=========================================================================  

#Count the number of vowels in a string
and i printed vowels but taking a empty list and appendin the vowels into it

a="Shreya"
v="AEIOUaeiou"
v_found=[]
c=0
for i in a:
    if i in v:
        c+=1
        v_found.append(i)
print(c)
print("".join(v_found))

=========================================================================

a="madam"
if a==a[::-1]:
    print("Palindrome")
else:
    print("NO")
===========================================================


#FIBINOCCI
n=int(input())
a=0
b=1
print(a, b, end=" ")
for i in range(n+1):
    c=a+b
    print(c, end=" ")
    a=b
    b=c
==========================================================================

#(to find the n-th Fibonacci number):
# Find the nth Fibonacci number
n = int(input("Enter the position (n): "))

a = 0
b = 1

if n == 0:
    print("Fibonacci number at position 0 is:", a)
elif n == 1:
    print("Fibonacci number at position 1 is:", b)
else:
    for i in range(2, n + 1):
        c = a + b
        a = b
        b = c
    print(f"Fibonacci number at position {n} is:", b)
    
==========================================================================

a=[1,95,883,4,2]
maxi=a[0]
for i in range(len(a)):
    if a[i]>maxi:
        maxi=a[i]
print(maxi)

========================================================================
#Frequency of each character        
a="hello"
dup={}
for i in a:
    if i in dup:
        dup[i]+=1
    else:
        dup[i]=1
print(dup)
===================================================================      

a=5
for i in range(a+1):
    for j in range(i+1):
        print('*',end=" ")
    print()

===================================================================
#Second Larger]st Numebr
a = [1, 2, 3, 4, 5, 6, 7]
max1 = max2 = float('-inf')

for num in a:
    if num > max1:
        max2 = max1
        max1 = num
    elif num > max2 and num != max1:
        max2 = num

print("Second Maximum:", max2)
---------------OR-------------------
a = [1, 2, 3, 4, 5, 6, 7]
a.sort()
print(a[-2])
==============================================================

a=[1,2,2,3,4,4,5]
d={}
for i in a:
    if i in d:
        d[i]+=1
    else:
        d[i]=1
        
uni=[]
for key in d:
    if d[key]==1:
        uni.append(key)
print(uni)
----------------------OR-----------------------------
a=[1,2,2,3,4,4,5]
print([i for i in a if a.count(i)==1])


============================================================================

a=[1,2,3,4,5]
sumi=0
for i in a:
    if i%2==0:
        sumi+=i
print(sumi)
==================================================================================
#COMMON ELEMNETS in LIST
a=[1,2,3]
b=[2,3,4]
print([i for i in a if i in b])
#print(list(set(a) & set(b)))
=============================================================================
#SORTED OR NOT
a=[3,4,5,1]
print("YES" if a==sorted(a) else "NO")
===================================================================
''
#ARMSTRONG
a=153
d=str(a)
s=len(d)
print("True" if sum(int(i)**s for i in d)==a else "False")
======================================================================



















'''


n=int(input())
for i in range(1,n+1):
    if i%2==0:
        print(i)


n=13
for i in range(2,int(n**0.5)+1):
    if i%n==0:
        print("True")
print("Truefalse")




a = 0
b = 1

print(a, b, end=" ")  # This prints: 0 1

for i in range(4):    # Loop 4 times because we already printed 2 numbers
    c = a + b         # c is the next number
    print(c, end=" ") # Print c
    a = b             # Move 'a' to the next number
    b = c             # Move 'b' to the new value

'''
