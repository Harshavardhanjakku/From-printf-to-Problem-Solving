'''x=int(input())
def E(x):
    if x%2==0:
        print("Even")
    else:
        print("Odd")
E(x)

a=int(input())
b=int(input())
flag=input()
if (a>=0 or b>=0) and flag=="False":
    print("True")
else:
    print("False")
    

def angry(j,s):
    if j and s =="True":
        print("Trouble")
    else:
        print("no ")
angry("True","True")


s=input()
c=s.count("cat")
h=s.count("hat")
if(c==h):
    print("true")
else:
    print("False")

n=int(input())
for i in range(1,11):
    print(n*i,end=' ')

n=input()
def str(n):
    for i in range(len(n)):
        if i % 2==0:
            print(n[i],end='')
str(n)


n=int(input())
def func(n):
    for i in range(n,-1,-1):
        print(i,end=' ')
func(n)
        


n = int(input("Enter a number: "))

def func(n):
    for i in range(1, int(n ** 0.5)+ 1):  # Loop from 1 to n
        print(i ** 2, end=" ")  # Print the square of i, with space separator

func(n)


n=int(input())
if(n==0):
    print("already zero")
else:
    def pos(n):
        for i in range(n,-1,-1):
            print(i,end=' ')

    pos(n)
    def neg(n):
        for i in range(n,1,1):
            print(i,end=' ')

    neg(n)
        


n=int(input())
def oe(n):
    if n%2==0:
        print("Even")
    else:
        print("Odd")
oe(n)


n=int(input())
sum=0
for i in range(0,n+1,1):
    sum=sum+i
print(sum,end=' ')



n=int(input())
for i in range(n):
    for j in range(i,n):
        print(' ',end='')
    for j in range(i):
        print('*',end='')
    for j in range(i+1):
        print('*',end='')
    print()


n=int(input(""))
for i in range(n):
    for j in range(i+1):
        print('*',end=' ')
    print()



n=int(input())
for i in range(n):
    for j in range(i+1):
        print(' ',end='')
    for j in range(i,n-1):
        print('*',end='')
    for j in range(i,n):
        print('*',end='')
    print()



n=int(input())
for i in range(n):
    for j in range(i,n):
        print(' ',end='')
    for j in range(i+1):
        print('*',end='')
    print()
    

a=list(map(int,input().split()))
mi=min(a)
ma=max(a)
print(f"The maximum and minimum are {mi} and {ma}")


a=list(map(int,input().split()))
b=list(map(int,input().split()))
d=list(set(a).intersection(b))
c=list(set(a+b))
print(c)
print(d)
print(len(c))


n=int(input())
for i in range(n):
    for j in range(i,n):
        print(' ',end='')
    for j in range(i):
        print('*',end='')
    for j in range(i+1):
        print('*',end='')   
    print()



a=[1,2,3,4]
b=a[0]
d=a[3]
print(f"initial {b} amd {d}")
temp=b
b=d
d=temp
print(b,d)

a=list(map(int,input().split()))
n=len(a)
a[0],a[n-1]=a[n-1],a[0]
print(f"my new list is {a}")

a=int(input())
b=int(input())
if a>b:
    print(a)
else:
    print(b)
    '''


a=[1,2,3,4]
a[0],a[2]=a[2],a[0]
print(a)
print(len(a))


    



