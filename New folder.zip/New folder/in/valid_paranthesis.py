# 🧠 Function to check if the parentheses are valid
def is_valid(s):
    stack = []  # 📦 Stack to store opening brackets
    mapping = {')': '(', '}': '{', ']': '['}  # 🔁 Matching pairs

    for char in s:
        if char in mapping.values():  # 🟢 If it’s an opening bracket: ( { [
            stack.append(char)        # ➕ Push it onto the stack
        elif char in mapping:         # 🔴 If it’s a closing bracket: ) } ]
            if not stack:             # ❌ Stack is empty → nothing to match
                return False
            if mapping[char] != stack.pop():  # ❌ Top doesn’t match expected opening
                return False

    return not stack  # ✅ If stack is empty → all matched → True
s="({]})"
print(is_valid(s))
'''
# 🎯 Test Cases

# ✅ Valid case
s1 = "({[]})"
print(f"Is '{s1}' valid? →", is_valid(s1))  # True

# ❌ Invalid case (wrong order)
s2 = "(]"
print(f"Is '{s2}' valid? →", is_valid(s2))  # False

# ✅ Valid case
s3 = "((()))"
print(f"Is '{s3}' valid? →", is_valid(s3))  # True

# ❌ Invalid case (extra closing)
s4 = "(()))"
print(f"Is '{s4}' valid? →", is_valid(s4))  # False

# ❌ Invalid case (extra opening)
s5 = "((("
print(f"Is '{s5}' valid? →", is_valid(s5))  # False
'''