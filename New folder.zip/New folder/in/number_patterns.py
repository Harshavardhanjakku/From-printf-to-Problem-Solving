'''
n=6
for i in range(1,n):
    for j in range(n-i):
        print(' ',end=' ')
    num=1
    for j in range(2*i-1):
        print(num,end=' ')
        num+=1
    print()
          1 
        1 2 3 
      1 2 3 4 5 
    1 2 3 4 5 6 7 
  1 2 3 4 5 6 7 8 9
================================================================
n=6
for i in range(1,n):
    for j in range(n-i):
        print(' ',end=' ')
    for j in range(2*i-1):
        print(i,end=' ')
    print()
          1 
        2 2 2 
      3 3 3 3 3 
    4 4 4 4 4 4 4 
  5 5 5 5 5 5 5 5 5
===================================================================
#FLOYD's TRIANGLE
n=6
num=1
for i in range(1,n):
    for j in range(i):
        print(num,end=' ')
        num+=1
    print()
1 
2 3 
4 5 6 
7 8 9 10 
11 12 13 14 15
=======================================================================
n=5
for i in range(1,n+1):
    for j in range(n-i):
        print(' ',end=' ')
    for j in range(1,i+1):
        print(j,end=' ')
    print()
        1 
      1 2 
    1 2 3 
  1 2 3 4 
1 2 3 4 5

==============================================================
n=5
for i in range(n,0,-1):
    for j in range(i,0,-1):
        print(j,end=' ')
    print()
5 4 3 2 1 
4 3 2 1 
3 2 1 
2 1 
1

n = 5  # Number of rows

triangle = []  # List to hold rows of Pascal's triangle

for i in range(n):
    row = [1] * (i + 1)  # Start each row with all 1s

    # Update values from 1 to i-1 (excluding first and last)
    for j in range(1, i):
        row[j] = triangle[i - 1][j - 1] + triangle[i - 1][j]

    triangle.append(row)  # Add row to the triangle

# Print the triangle
for row in triangle:
    print(' '.join(str(num) for num in row))

n = 5  # Total number of rows

for i in range(n):  # For each row from 0 to n-1

    # Step 1: Print spaces to center align the triangle
    for j in range(n - i - 1):
        print(' ', end=' ')

    # Step 2: Print numbers in the row using binomial coefficients
    num = 1  # First number in every row is 1
    for j in range(i + 1):

        print(num, end=' ')
        
        # Calculate next number using: C(n, k) = C(n, k-1) * (n - k) / (k + 1)
        num = num * (i - j) // (j + 1)  # Integer division ensures no floats

    print()  # Move to next row
        1
      1 1
    1 2 1
  1 3 3 1
1 4 6 4 1
'''
n = 5  # Total number of rows

for i in range(n):  # For each row i (from 0 to n-1)

    # Step 1: Print leading spaces to center the triangle
    for j in range(n - i - 1):
        print("  ", end='')  # Two spaces for better alignment

    # Step 2: Print Pascal's Triangle numbers using binomial coefficient
    num = 1  # First number of every row is always 1
    for j in range(i + 1):

        print(f"{num:<3}", end=' ')  # Print number with spacing (left aligned in 3-width)

        # Generate next number using C(n,k) = C(n,k-1) * (n-k) / (k+1)
        num = num * (i - j) // (j + 1)

    print()  # Move to the next row

        1
      1   1
    1   2   1
  1   3   3   1
1   4   6   4   1

