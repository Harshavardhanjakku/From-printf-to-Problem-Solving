'''
#TECH DSA

1..............#REVERSING A STRING.....................................
a="hello"
print(a[::-1])
#----or-------
a="hElLo"
a=list(a)
l=0
r=len(a)-1
while l<r:
    a[l],a[r]=a[r],a[l]
    l+=1
    r-=1
print(''.join(a))




#2................FIND MAXIMUM AND MINIMUM IN A ARRAY......................................
a=[1,2,3,4,5]

maxi,mini=a[0],a[0]
for i in a:
    if i>maxi:
        maxi=i
    elif i<mini:
        mini=i
print(maxi,mini)
        
'''


#3.........................CHECH IF ARRAY IS SORTED AND ROTATED................................
a=[6,5,8,1,2,3,4]
b_p=0
for i in range(len(a)):
    cu=a[i]
    next=a[(i+1)%len(a)]
    if cu>next:
        b_p+=1
        if b_p>1:
            print("False")
            break
else:
    print("True")


#4.............................REMOVE DUPLICATES FROM SORTED ARRAY---------------------------------
    
class Solution:
    def removeDuplicates(self, nums: List[int]) -> int:
        if not nums:  # if array is empty
            return 0

        j = 0  # j is the pointer for the "place of unique elements"

        for i in range(1, len(nums)):  # start from 1 because nums[0] is always unique
            if nums[i] != nums[j]:   # found a new unique number
                j += 1               # move j ahead
                nums[j] = nums[i]    # place the unique number at nums[j]

        return j + 1  # length of unique elements

    
    

    
        
        


    