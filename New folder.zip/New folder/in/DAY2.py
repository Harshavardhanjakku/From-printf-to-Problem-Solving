'''a=int(input())
print("Even " if a%2==0 else "False")

a=int(input())
b=int(input())
c=int(input())
if a>b and a>c:
    print(f"{a} is greater")
elif b>c:
    print(b)
else:
    print(c)
   

a=int(input())
print("Leap" if a%4==0 else "Not")
 '''

a=input()
v="AEIOUaeiou"
if a in v:
    print("Vowel")
else:
    print("C")
        