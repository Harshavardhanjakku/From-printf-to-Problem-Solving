#TWO SUM
def two_sum(arr,tar):
    seen={}
    for i,val in enumerate(arr):
        diff=tar-val
        if diff in seen:
            return[seen[diff],i]
        seen[val]=i
arr=list(map(int,input().split()))
tar=int(input())
print(two_sum(arr,tar))