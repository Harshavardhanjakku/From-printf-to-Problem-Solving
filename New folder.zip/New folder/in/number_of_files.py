import os

def find_all_files(root_path):
    all_files = []

    def dfs(current_path):
        # Try to list files in current_path
        try:
            for entry in os.listdir(current_path):
                full_path = os.path.join(current_path, entry)

                # If it's a file, add to list
                if os.path.isfile(full_path):
                    all_files.append(full_path)

                # If it's a directory, recurse
                elif os.path.isdir(full_path):
                    dfs(full_path)
        except PermissionError:
            # Skip folders we can't access
            pass
        except FileNotFoundError:
            # Skip if the folder suddenly disappears
            pass

    dfs(root_path)
    return all_files

# Example usage:
start_path = "C:\\"  # Use "/" for Linux/Mac
files = find_all_files(start_path)

# Print first 20 files for example
for f in files[:20]:
    print(f)

print(f"\nTotal files found: {len(files)}")
