def move_zeroes(nums):
    non_zero = 0  # keeps track of where to place the next non-zero

    for i in range(len(nums)):  # go through each number
        if nums[i] != 0:  # if current number is NOT zero
            nums[non_zero], nums[i] = nums[i], nums[non_zero]  # swap non-zero forward
            non_zero += 1  # move to next spot for placing non-zero
nums=[2,0,3,0,5,0,4,0]
move_zeroes(nums)
print(nums)