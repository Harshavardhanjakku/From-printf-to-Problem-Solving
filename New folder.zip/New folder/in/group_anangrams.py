from collections import defaultdict  # 📦 Import defaultdict from collections

# 🔠 Function to group words that are anagrams
def group_anagrams(strs):
    result = defaultdict(list)  # 🍱 Creates a dictionary where each value is a list

    for word in strs:
        # ✨ Sort the word to create a key: "eat" → "aet", "tea" → "aet"
        key = ''.join(sorted(word))

        # ➕ Add the original word to the list corresponding to its sorted key
        result[key].append(word)

    # 📦 Return all the grouped anagram lists
    return list(result.values())


# 🎯 Example input
words = ["eat", "tea", "tan", "ate", "nat", "bat"]

# 📞 Call the function
anagram_groups = group_anagrams(words)

# 🖨️ Output the result

print(anagram_groups)



'''
Absolutely, Chinni! 🍼💖
Let me explain this **Group Anagrams** code in **super baby-level**, step-by-step — as if you're new to coding and we're solving a magical word puzzle together 🧩✨

---

## 🎯 Problem:

You're given a list of words like:

```python
strs = ["eat", "tea", "tan", "ate", "nat", "bat"]
```

You need to group all **anagrams** together.

### 🔤 What are anagrams?

Words that have the **same letters** but in **different order**.

Examples:

* "eat", "tea", and "ate" are anagrams
* "tan" and "nat" are anagrams
* "bat" stands alone

✅ Expected output:

```python
[["eat", "tea", "ate"], ["tan", "nat"], ["bat"]]
```

---

## ✅ Full Code

```python
from collections import defaultdict

def group_anagrams(strs):
    result = defaultdict(list)  # 🍱 A special dictionary where default value is an empty list

    for word in strs:
        key = ''.join(sorted(word))  # 🔤 Sort the letters of the word to create a key
        result[key].append(word)     # ➕ Add the original word to the correct group

    return list(result.values())  # 🧺 Return all grouped lists
```

---

## 👶 Baby-Level Explanation:

### 🔸 `from collections import defaultdict`

This gives us a **special dictionary** where:

* If a key doesn't exist yet, it automatically creates an **empty list**.
* So we don’t need to write extra code like `if key not in dict: ...`

---

### 🔸 `result = defaultdict(list)`

We create an empty dictionary named `result` that looks like:

```python
result = {}
```

but it **automatically makes empty lists** when a new key is used.

---

### 🔁 Loop through each word:

```python
for word in strs:
```

We go through each word one by one in the list `strs`.

---

### 🔤 Sorted word as key:

```python
key = ''.join(sorted(word))
```

This is the magic part! ✨
We sort the letters in the word to make a **standard version** of it.

| Word  | `sorted(word)`   | `key` (after join) |
| ----- | ---------------- | ------------------ |
| "eat" | \['a', 'e', 't'] | "aet"              |
| "tea" | \['a', 'e', 't'] | "aet"              |
| "ate" | \['a', 'e', 't'] | "aet"              |
| "tan" | \['a', 'n', 't'] | "ant"              |
| "nat" | \['a', 'n', 't'] | "ant"              |
| "bat" | \['a', 'b', 't'] | "abt"              |

So all anagrams get the **same key**.

---

### 🧺 Add to result dictionary:

```python
result[key].append(word)
```

We use the sorted key to **group** the word.

After full loop, the dictionary looks like:

```python
{
  "aet": ["eat", "tea", "ate"],
  "ant": ["tan", "nat"],
  "abt": ["bat"]
}
```

---

### ✅ Finally:

```python
return list(result.values())
```

This takes all the **grouped lists** and gives them as a big list of groups:

```python
[["eat", "tea", "ate"], ["tan", "nat"], ["bat"]]
```

---

## 📦 Baby Analogy:

Imagine you’re putting toys (words) into baskets (groups):

* All toys with the same **shape of letters** go into the same basket.
* Sorting the letters helps you see which toys match.
* The basket labels are sorted letters like `"aet"`, `"ant"`, `"abt"`.

---

## 🧪 Test Example

```python
words = ["eat", "tea", "tan", "ate", "nat", "bat"]
print(group_anagrams(words))
```

### ✅ Output:

```python
[['eat', 'tea', 'ate'], ['tan', 'nat'], ['bat']]
```

---

## 💡 Summary

| Line                       | What it does                            |
| -------------------------- | --------------------------------------- |
| `defaultdict(list)`        | Automatically creates list for new keys |
| `sorted(word)`             | Gets a “signature” for grouping         |
| `result[key].append(word)` | Adds word to the correct group          |
| `list(result.values())`    | Returns all the anagram groups          |

---

Want me to give you:

* A version that prints step-by-step for each word?
* Practice question based on this?

Let me know, Chinni! You’re grouping your way to greatness 🌟🧺
'''
