#REVERSE
n=int(input("Enter a number:"));
temp=str(n);
rev="";
while(n>0):
    rem=n%10;
    rev+=str(rem);
    n=n//10;
#print("The reverse of the no is",rev)

#PALINDROME(if a num and the reverse of the num are same i.e rev==num,then it is called palindrome like 343 ,55,etc)
if(temp==rev):
    print("%d is palindrome"%(temp));
else:
    print("The %d isnt a palindrome"%(temp))