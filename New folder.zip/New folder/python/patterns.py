'''#SQUARE
n=6
for i in range(n):
    for j in range(n):
        print('*',end=" ")
    print()

#InCREASING 
n=6
for i in range(n):
    for j in range(i+1):
        print('*',end=" ")
    print()

#DECRESING 
n=6
for i in range(n):
    for j in range(i,n):
        print("*",end=" ")
    print()'''
''''
n=6
for i in range(1,n+1):
    for j in range(1,i+1):
        print(j,end='')
    print()'''
'''
n=6
for i in range(1,n+1):
    for j in range(1,i+1):
        print(j,end=" ")
    print()

n=6
for i in range(1,n+1):
    for j in range(i,n):
        print(j,end=" ")
    print()'''

'''n=6
for i in range(1,n):
    for j in range(1,i+1):
        print(j,end=" ")
    print()
'''
n=6
for i in range(n):
    for j in range(n-i-1):
        print('',end=" ")
    for j in range(i+1):
        print(j+1,end=" ")
    print()