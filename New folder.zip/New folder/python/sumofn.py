
#SUM OF N NATURAL NO.S
a=int(input("Enter the last no."));
sum=0;
for i in range(1,a+1):
    sum+=i;
print(sum)
print(a*(a+1)//2)
'''
n=15
b=int(input("Enter the no. that u wanna divide"));
if(b==3):
    print("Harsha");
elif(b==5):
    print("Sunny");
else:
    print("HarshaSunny");
'''
