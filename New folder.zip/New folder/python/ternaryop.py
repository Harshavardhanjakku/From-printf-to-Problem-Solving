#biggest of 3 no.s
'''a=int(input("enter first no"));
b=int(input("enter sec no"));
c=int(input("enter third no"));
if(a>b and a>c):
    print("a");
elif(b>c):
    print(b);
else:
    print(c)'''

#biggest of 3 no.s using ternary operator

a=int(input("enter first no"));
b=int(input("enter sec no"));
c=int(input("enter third no"));
big="greatest is  %d"%(a) if a>b and a>c else "%d is greatest" %(b) if b>c else" %d is greatest"%(c);
print(big)

