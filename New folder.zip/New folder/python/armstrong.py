n=int(input("Enter a num:"));
l=len(str(n)); #len i.e length keyword is used for strings so we are converting integer i.e n to str and calculating its length so tht we can multipy the length to its power to calculate armstrong
temp=n;
sum=0;
rem=0;
while(n>0):
    rem=n%10;
    sum=sum+rem**l;
    n=n//10;
if(temp==sum):
    print("%d is arm"%(temp));
else:
    print("%d is not arm"%(temp));
