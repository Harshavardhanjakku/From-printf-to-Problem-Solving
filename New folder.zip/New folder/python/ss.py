
'''for i in range(1,6):
    for j in range(1,5):
        print(i,end =" ");
print()
'''
#s="Shreya"
#print(str.lower(s))


#EVEN CHARACTERS AND ODD CHARACTERS
'''n=input("Enter a string");
even=[];
odd="";
for i in range(len(n)):
    if i%2==0:
        even.append(n[i]);
    else:
        odd=odd+n[i];
print("even character: {}".format(even));
print(odd)'''

#Alternative lower and upper case respectively
n=input("Enter a string");
new="";
for i in range(len(n)):
    if i%2==0:
        new+=str.lower(n[i]);
    else:
        new+=str.upper(n[i]);
print(new)