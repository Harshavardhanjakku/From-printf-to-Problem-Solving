'''n=int(input("Enter num:"))
for i in range(n):
    for j in range(i):
        print(" ",end=" ")
    for j in range(n-i):
        print(j+1,end=" ")
    print()'''

'''n=int(input("Enter the num:"))
for i in range(n):
    for j in range(i):
        print(j+1,end=" ")
    print()
    '''

#UPPER TRIANGLE
# n=6;
# for i in range(n):
#     for j in range(i+1):
#         print("*",end='   ')
#     print()
#LOWER TRIANGLE
# n=6
# for i in range(n):
#     for j in range(i,n):#for j in range(n-i)
#         print("#",end=' ');
#     print()

#RIGHT SIDED TRIANGLE
# n=6
# for i in range(n):
#     for j in range(i,n):
#         print(' ',end=' ');
#     for j in range(i+1):
#         print('*',end=' ');
#     print()


# n=6
# for i in range(n):
#     for j in range(i+1):
#         print(' ',end=' ')
#     for j in range(i,n):
#         print('*',end=' ')
#     print()

# n=5;
# for i in range(n):
#     for j in range(i,n):
#         print(' ',end=' ')
#     for j in range(i):
#         print('*',end=' ');
#     for j in range(i+1):
#         print('*',end=' ');
#     print()
n=6;
for i in range(n):
    for j in range(i+1):
        print(' ',end=' ');
    for j in range(i,n-1):
        print('#',end=' ');
    for j in range(n-i):
        print('*',end=' ');
    print()