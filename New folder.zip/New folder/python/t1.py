#Diffrent ways of printing
n=input("Enter your name:");
a=int(input("Enter ur age:"));
print("My name is",n ," and age is",a)
print("My name is %s and age is %d" %(n,a))
print(f"My name is {n} and age is {a}")
print("My name is {} and age is {}".format(n,a))


c=3.00000000000000000001
flag=0
if c==int(c):
    flag=True;
else:
    flag=False
print(flag)


