'''a=input("Enter")
new=""
for i in range(len(a)):
    if i%2==0:
        new=new+str.lower(a[i])
    else:
        new=new+str.upper(a[i])
print(new)
'''

'''for i in range(9):
    print(i,end="")'''

'''a=input("")
for i in range(len(a)):
    print(a[i])

'''
'''a=input("Enter")
even=""
odd=""
for i in range(len(a)):
    if i%2==0:
        even=even+a[i]
    else:
        odd=odd+a[i]
print(even,odd)
print(odd)
'''

