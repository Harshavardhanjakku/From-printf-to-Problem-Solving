#FACTORIAL OF A NUMBER
import math 
n=int(input("Enter a num"));
fact=1 # we take fact=1 as multiplicative identity is 1 ,for addition we take o like sum=0
for i in range(1,n+1):
    fact=fact*i;
print("Factorial of n is ",fact)
print("factorial of num is:",math.factorial(n))