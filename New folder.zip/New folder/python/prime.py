# PRIME
n=int(input("Enter a num:"));
count=0;
for i in range(1,n+1):
    if(n%i==0):
        count+=1;
if(count==2):
    print(" %d is prime"%(n));
else:
    print(count)