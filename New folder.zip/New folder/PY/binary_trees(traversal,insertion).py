from collections import deque

class Node:
    def __init__(self, value):
        self.left = None
        self.data = value
        self.right = None

class BinaryTree:
    @staticmethod
    def insert_node(root, value):
        if root is None:
            return Node(value)
        q = deque()
        q.append(root)
        while q:
            a = q.popleft()
            if not a.left:
                a.left = Node(value)
                return
            else:
                q.append(a.left)
            if not a.right:
                a.right = Node(value)
                return
            else:
                q.append(a.right)

def level_order_traversal(root):
    if root is None:
        return []
    q = deque([root])
    result = []
    while q:
        node = q.popleft()
        result.append(node.data)
        if node.left:
            q.append(node.left)
        if node.right:
            q.append(node.right)
    return result

root = Node(5)
BinaryTree.insert_node(root, 10)
BinaryTree.insert_node(root, 15)
for i in range(20, 30):
    BinaryTree.insert_node(root, i)
print(level_order_traversal(root))