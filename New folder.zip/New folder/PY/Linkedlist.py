#SINGLE LINKED LIST
class Node:#list contains nodes
    def __init__(self,data):#node contains two values(data and address)
        self.data=data
        self.next=None
    head=None#first headis null
    tail=None
#assigning values static
first=Node(10)
second=Node(20)
third=Node(30)
fourth=Node('Shreya')#we can write strings in lineked list
#now headis first and connecting
head=first
tail=fourth
first.next=second
second.previous=first
second.next=third
third.previous=second
third.next=fourth
fourth.previous=third
fourth.next=None

#TRAVERSING
temp=head
while temp!=None:
    print(temp.data)
    temp=temp.next
'''
#printing 
print(head.data)
print(head)#for getting addresss
print(head.next.data)
print(head.next.next.data)
print(head.next.next.next.data)'''