'''n=5
for i in range(n):
    for j in range(i,n):
        print(' ',end=" ")
    for j in range(i):
        print('*',end=" ")
    for j in range(i+1):
        print('*',end=" ")
    print()


n=int(input("Enter a num: "))
temp=n
rev=0
while temp>0:
    rem=temp%10
    rev=(rev*10)+rem
    temp=temp//10
if rev==n:
    print("YES")
else:
    print("No")
   

n=input()
rev=n[::-1]
if rev==n:
    print("YES")
else:
    print("NO")
    

n=int(input("ENter "))
le=len(str(n))
temp=n
sum=0
while temp>0:
    rem=temp%10
    sum=sum+rem**le
    temp=temp//10
if sum==n:
    print("aaaarm")
else:
    print("No arm")
    
    
    
n=int(input("ENter a num: "))
if n==0 or n==1:
    print("Not Prime nor composite")
elif n>1:
    for i in range(2,n//2+1):
        if n%i==0:
            print(f" {n} Not a prime")
            break
    else:
        print(" prime")
'''


