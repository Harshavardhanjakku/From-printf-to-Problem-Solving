from collections import deque
def bfs(graph,start):
    visited=set()
    queue=deque([start])
    visited.add(start)
    while queue:
        node=queue.popleft()
        print(node,end=" ")
        for neigh in graph[node]:
            if neigh not in visited:
                visited.add(neigh)
                queue.append(neigh)
graph={0:[1,3],
       1:[0,2,5,6],
       2:[1,3,5,4],
       3:[0,4,2],
       4:[3,2,6],
       5:[1,2],
       6:[1,4]
       }
bfs(graph,0)