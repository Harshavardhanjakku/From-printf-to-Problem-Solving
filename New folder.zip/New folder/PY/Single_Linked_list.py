class Node:
    def __init__ (self,value):
        self.data=value
        self.link=None
class LinkedList:
    def __init__(self):
        self.head=None
    def insert_at_begin(self,value):
        new_node=Node(value)
        if self.head==None:
            self.head=new_node
            return
        new_node.link=self.head
        self.head=new_node
    def traversal(self):
        if self.head==None:
            print("Linked list is empty")
            return
        temp=self.head
        while temp!=None:
            print(temp.data,end="-->")
            temp=temp.link
        print("NULL")
Obj=LinkedList()
Obj.insert_at_begin(111)
Obj.insert_at_begin(222)
Obj.insert_at_begin(333)
Obj.traversal()