class PostfixEvaluator:
    def __init__(self,postfix):
        self.postfix_exp=postfix
        self.stack=[]
    def evaluate(self):
        for symbol in self.postfix_exp:
            if symbol.isdigit():
                self.stack.append(int(symbol))
            else:
                operand2=self.stack.pop()
                operand1=self.stack.pop()
                if symbol=='+':
                    res=operand1+operand2
                elif symbol=='-':
                    res=operand1-operand2
                elif symbol=='*':
                    res=operand1*operand2
                elif symbol=='/':
                    res=operand1/operand2
                self.stack.append(res)
        return self.stack[0]
postfix="432*+5-"
obj=PostfixEvaluator(postfix)
print("Postfix Expression: ",postfix)
print("Result: ",obj.evaluate())
                