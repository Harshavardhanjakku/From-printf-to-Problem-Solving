class Queue:
    def __init__(self):
        self.queue = []
        self.rear=-1
        self.front=-1
        self.max_size=5
    def enqueue(self,ele):
        if self.rear==self.max_size-1:
            print("Queue is Full")
            return
        if self.front==-1:
            self.front==0
        self.rear=self.rear+1
        self.queue.append(ele)
    def dequeue(self):
        if self.front==-1:
            print("Queue is empty")
            return
        temp=self.queue[self.front]
        self.queue[self.front]=None
        if self.front==self.rear:
            self.front=self.rear=-1
        self.front=self.front+1
        return temp
    def disp(self):
        print(self.queue)
        print(*self.queue)#to display list without square brackets and commas
        
q = Queue()
q.enqueue(1)
q.enqueue(2)
q.enqueue(9)
q.dequeue()
q.disp()
