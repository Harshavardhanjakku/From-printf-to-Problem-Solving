from collections import deque
q=deque()
q.append(10)
q.append(20)
q.append(30)
print(*q)

q.appendleft(100)
q.appendleft(200)
print(*q)

q.pop()
print(*q)

q.popleft()
print(*q)