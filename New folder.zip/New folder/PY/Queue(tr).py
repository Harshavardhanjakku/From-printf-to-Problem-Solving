class Queue:
    def __init__(self):
        self.queue = []

    def enqueue(self, element):
        self.queue.append(element)
        print(f"Enqueued {element}: {self.queue}")

    def dequeue(self):
        if len(self.queue) == 0:
            return "Queue is empty"
        return self.queue.pop(0)

    def peek(self):
        if len(self.queue) == 0:
            return "Queue is empty"
        return self.queue[0]

    def is_empty(self):
        return len(self.queue) == 0

    def size(self):
        return len(self.queue)
    
q = Queue()
q.enqueue(1)
q.enqueue(2)
q.enqueue(3)

print(f"Dequeued: {q.dequeue()}")
print(f"Queue: {q.queue}")
print(f"Peek: {q.peek()}")
print(f"Is queue empty? {q.is_empty()}")
print(f"Size of queue: {q.size()}")