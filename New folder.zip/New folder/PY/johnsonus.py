def jo(n,k):
    queue=list(range(1,n+1))
    index=0
    while len(queue)>1:
        index=(index+k-1) %len(queue)
        queue.pop(index)
    return queue[0]
n=int(input())
k=int(input())
print(jo(n,k))