class ParaCheck:
    def __init__ (self):
        self.stack=[]
    def push(self, char):
        self.stack.append(char)
    def pop(self):
        if self.stack:
            return self.stack.pop()
        else:
            return False
    def is_balanced(self,expression):
        for char in expression:
            if char=='(':
                self.push(char)
            elif char==')':
                if not self.pop():
                    return "Expression is unbalanced"
        if not self.stack:
            return "Expression is balanced"
        else:
            return "Expression is unbalanced"
expression=input("Enter an expression: ")
checker=ParaCheck()
result=checker.is_balanced(expression)
