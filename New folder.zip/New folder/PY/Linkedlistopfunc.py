'''sll using insertatbegin and insertionatend'''
class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
class SLL:
    def __init__(self):
        self.head=None
        
    def insertAtBegin(self,new_data):
        if self.head==None:
            new_node=Node(new_data)
            self.head=new_node
        else:
            new_node=Node(new_data)
            new_node.next=self.head
            self.head=new_node
            
    def display(self):
        if self.head==None:
            print('ll is empty')
        else:
            temp=self.head
            while temp!=None:
                print(temp.data)
                temp=temp.next
                
    def insertatend(self,new_data):
        if self.head==None:
            new_node=Node(new_data)
            self.head=new_node
        else:
            new_node=Node(new_data)
            temp=self.head
            while temp.next:
                temp=temp.next
            temp.next=new_node
                
obj=SLL()
obj.insertatend(100)
obj.insertatend(200)
obj.insertAtBegin(10)
obj.insertAtBegin(20)
obj.insertatend('sru')
obj.insertAtBegin(30)
obj.insertAtBegin(40)
obj.insertatend(50)
obj.display()