class Node:
    # Constructor to initialize a Node with a given value
    def __init__(self, val):  # Corrected the method name from '_init' to '_init_'
        self.data = val  # The value/data of the node
        self.next = None  # The reference to the next node

class QueueLL:
    def __init__(self):
        # Initializes an empty queue with front and rear set to None
        self.front = None
        self.rear = None

    def enqueue(self, val):
        # Adds a new element at the rear of the queue
        new_node = Node(val)  # Create a new node with the given value
        if self.front is None:  # If the queue is empty
            self.front = new_node  # Set the new node as the front
            self.rear = new_node  # Set the new node as the rear
            return
        # Link the new node to the current rear and update rear
        self.rear.next = new_node
        self.rear = new_node

    def dequeue(self):
        # Removes and returns the front element of the queue
        if self.front is None:  # If the queue is empty
            print("Queue is empty")
            return
        temp = self.front.data  # Store the data of the front node
        self.front = self.front.next  # Move the front to the next node
        return temp  # Return the dequeued value

    def getRear(self):
        # Returns the data of the rear element without removing it
        if self.front is None:  # If the queue is empty
            print("Queue is empty")
            return
        return self.rear.data  # Return the data at the rear

    def getFront(self):
        # Returns the data of the front element without removing it
        if self.front is None:  # If the queue is empty
            print("Queue is empty")
            return
        return self.front.data  # Return the data at the front

    def display(self):
        # Prints all the elements of the queue from front to rear
        if self.front is None:  # If the queue is empty
            print("Queue is empty")
            return
        temp = self.front  # Start from the front
        while temp:
            print(temp.data, end="-->")  # Print data with '->' as a separator
            temp = temp.next  # Move to the next node
        print("None")  # Indicate the end of the queue

# Creating an object of QueueLL
ob = QueueLL()
# Enqueuing elements into the queue
ob.enqueue(11)
ob.enqueue(22)
ob.enqueue(33)
ob.enqueue(44)
# Displaying the queue elements
ob.display()