#DOUBLE LINKED LIST
class Node:
    def __init__(self,value):
        self.prev=None
        self.data=value
        self.next=None
class DLL:
    def __init__(self):
        self.head=None
    def traversal(self):
        if self.head==None:
            print("DLL is empty")
            return
        temp=self.head
        while temp:
            print(temp.data,end="-->")
            temp=temp.next
    def ins_at_end(self,value):
        newnode=Node(value)
        if self.head==None:
            self.head=newnode
            return
        temp=self.head
        while temp.next:#temp.next!=None
            temp=temp.next
        temp.next=newnode
        newnode.prev=temp
    
    def ins_at_beg(self,value):
        newnode=Node(value)
        if self.head==None:
            self.head=newnode
            return
        newnode.next=self.head
        self.head=newnode
    def dele_at_beg(self):
        if self.head==None:
            print("DLL is empty")
            return
        self.head=self.head.next
        self.head.prev=None
    def dele_at_end(self):
        if self.head==None:
            print("DLL is empty")
            return
        if self.head.next==None:
            self.head=None
            return
        temp=self.head
        before=None
        while temp.next!=None:
            before=temp
            temp=temp.next
        before.next=None
        
          
           
obj=DLL()
obj.ins_at_end(2)
obj.ins_at_beg(20)
obj.ins_at_beg(30)
obj.ins_at_end(6)
obj.dele_at_beg()
obj.dele_at_end()
obj.traversal()