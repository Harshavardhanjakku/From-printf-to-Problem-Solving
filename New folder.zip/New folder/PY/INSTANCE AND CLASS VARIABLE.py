#CLASS VARIABLES and INSTANCE Variables
class Student:
    Course="BTECH"
    def __init__(self,name,roll,marks):
        self.name=name
        self.roll=roll
        self.marks=marks
        Student.Course
    def display(self):
        print("Name : ",self.name)
        print("Roll: ",self.roll)
        print("Marks: ",self.marks)
    def __del__(self):#Destructor which deltes 
        print("Dlete everything")
        
s1=Student("Shreya",1017,100)
print(Student.Course)
s1.display()