class Node:
    def __init__ (self,value):
        self.data=value
        self.link=None
class cll:
    def __init__(self):
        self.head=None
    def traversal(self):
        if self.head==None:
            print("Circular Linked list is empty")
            return
        temp=self.head
        while temp.link!=self.head:
            print(temp.data,end="-->")
            temp=temp.link
        print(temp.data)
    def insert_at_end(self,value):
        new_node=Node(value)
        if self.head==None:
            self.head=new_node
            new_node.link=self.head
        temp=self.head
        while temp.link!=self.head:
            temp=temp.link
        temp.link=new_node
        new_node.link=self.head
    def insert_at_begin(self,value):
        new_node=Node(value)
        if self.head==None:
            self.head=new_node
            new_node.link=self.head
        temp=self.head
        while temp.link!=self.head:
            temp=temp.link
        temp.link=new_node
        new_node.link=self.head
        self.link=new_node
ob=cll()
ob.insert_at_begin(6)
ob.insert_at_begin(7)
ob.traversal()