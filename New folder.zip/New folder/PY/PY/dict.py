menu={
    'biryani':780,
    'mandi':780,
    'butter_chicken':780,
    'buffelo':780,
    'buurger':780,
    'bir':780,
    }
k,v=input(),int(input())
if k in menu.keys():
    print("Exists")
else:
    menu[k]=v
    print("Added Successfully")