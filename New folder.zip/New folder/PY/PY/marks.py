per=int(input("ENter the percentage: "))
if(per<=100 and per>=91):
    print("O")
elif(per<=90 and per>=81):
    print("A+")
elif(per<=80 and per>=71):
    print("A")
elif(per<=70 and per>=61):
    print("B+")
elif(per<=60 and per>=51):
    print("B")
elif(per<=50 and per>=41):
    print("C")
else:
    print("FAIL")
    

    


    
