a=int(input("Enter a num:"))
if(a>0):
    print("POSITIVE")
else:
    print("NEGATIVE")
    