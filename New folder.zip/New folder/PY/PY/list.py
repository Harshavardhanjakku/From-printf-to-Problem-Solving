fruits=["aa","bb","cc"]
fruits.append("KIWI")
print(fruits)

fruits.pop()
print(fruits)

fruits.pop(2)
print(fruits)

fruits.insert(3,"BERRYY")
print(fruits)

fruits.remove('aa')
print(fruits)

fruits.reverse()
print(fruits)

fruits=fruits[::-1]
print(fruits)

'''frs=list(map(str,input().split()))
print(frs)
for i in fr:
    print(i,end=" ")'''