class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None

def insert_bst(root,new_data):
    if root==None:
        root=Node(new_data)
        return root
    else:
        if new_data<root.data:
            root.left=insert_bst(root.left,new_data)
        if new_data>root.data:
            root.right=insert_bst(root.right,new_data)
        return root
def search_bst(root,target):
    if root==None:
        return False
    if root.data==target:
        return True
    else:
        if root.left:
            if target<root.data:
                return search_bst(root.left,target)
        if root.right:
            if target>root.data:
                return search_bst(root.right,target)
        return False

'''def findMax(root):
    if root==None:
        return
    else:
        max=root.data
        if root.right:
            if root.right.data>max:
                max=root.right.data
                return findMax(root.right)
        return max'''
def findMax(root):
    if root==None:
        return
    elif root.right==None:
        return root.data
    else:
        return findMax(root.right)
        
            
def preOrder(root):
    if root==None:
        return
    else:
        print(root.data)
        preOrder(root.left)
        preOrder(root.right)
        
root=Node(10)
insert_bst(root,5)
insert_bst(root,15)
insert_bst(root,20)
insert_bst(root,2)
preOrder(root)
print()
print(search_bst(root,15))
print("The max node: ",max(root))