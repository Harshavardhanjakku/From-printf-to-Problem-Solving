class Parent:
    def eat():
        print("this is parent class")
class Child(Parent):
    def food():
        print("I love biryani")
class Child2(Parent):
    def foodie():
        print("I love Chocolates")
cobj1=Child
cobj2=Child2
cobj1.eat()
cobj1.food()
cobj2.eat()
cobj2.foodie()


