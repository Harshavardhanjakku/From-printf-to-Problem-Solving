stud=(101,'Shreya',123)#IMMUTABLE
stud=list(stud)#Converting into list to make CRUD operations




###SETSSS
s={1,2,3,4}
s.add(500)
s.pop()
print(s)

