#ABSTRACTION
from abc import ABC,abstractmethod
class Employee(ABC):
    def hike():
        pass
    def salary():
        print("Yes thesres a salary provided")
class Shreya(Employee):
    def hike():
        print("Shreya got 5% hike")
    def salary():
        print("Shreya has got more salary than expected")#overide
class Sunny(Employee):
    def hike():
        print("Sunny got 2% hike")
class Bunny(Employee):
    def hike():
        print("Bunny got 1% hike")
        
c2=Shreya
c2.hike()
c2.salary()
print()
c1=Bunny
c1.hike()
c1.salary()
    
