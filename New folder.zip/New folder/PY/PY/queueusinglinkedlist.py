class Node:
    def _init_(self,data):
        self.data=data
        self.next=None
class Queuell:
    def _init_(self):
        self.rear=None
        self.front=None
    def enqueue(self,new_data):
        newnode=Node(new_data)
        if self.rear==None or self.front==None:
            newnode.next=self.rear
            self.rear=newnode
            self.front=newnode
        else:
            self.rear.next==None
            self.rear.next=newnode
            self.rear=newnode
            
    def dequeue(self):
        if self.rear==None or self.front==None:
            print('queuell is underflow')
        else:
            if self.front.next==None:
                self.front=None
            else:
                temp=self.front
                self.front=temp.next
                temp=None
        
    def display(self):
        if self.rear==None or self.front==None:
            print('queuell is empty')
        else:
            temp=self.front
            while temp:
                print(temp.data)
                temp=temp.next

obj=Queuell()

obj.enqueue(10)
obj.enqueue(20)
obj.enqueue(30)
obj.enqueue(40)
obj.dequeue()
obj.display()