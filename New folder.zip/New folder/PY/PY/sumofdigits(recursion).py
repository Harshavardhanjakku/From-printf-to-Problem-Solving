#Sum of digits using RECURSION
n=int(input())
def sum(n):
    if n==1 or n==0:
        return n
    else:
        return n%10+sum(n//10)
print(sum(n))
