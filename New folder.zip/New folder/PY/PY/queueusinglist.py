class QueueList:
    def __init__(self):
        self.queue=[]
    def enqueue(self,data):
        self.queue.append(data)
        return self.queue
    def dequeue(self):
        if self.queue==[]:
            print("underflow")
        else:
            self.queue.pop()
            return self.queue
    def display(self):
        if self.queue==[]:
            print("Queue is empty")
        else:
            for i in range(len(self.queue)):
                print(self.queue[i])
oj=QueueList()
oj.enqueue(10)
oj.enqueue(20)
oj.enqueue('sru')            
#oj.dequeue()
oj.display()