class Person:
    def __init__(self,name,age,place):
        self.name=name
        self.age=age
        self.place=place
    def __str__(self):
        return (f"The name is {self.name} with age {self.age} and living in {self.place}")
class Student(Person):
    def __init__(self,name,age,place,roll,branch,college):
        super().__init__(name,age,place)
        self.roll=roll
        self.branch=branch
        self.college=college
    def __str__(self):
        sdetails=super().__str__()
        return f"{sdetails} and my roll {self.roll} in {self.branch} in {self.college}"
s1=Student('Shreya',12,'WGL',1017,'CSE',"SRU")
print(s1)

