#dynamically
n=5
a=[]
for i in range(n):
    a.append(int(input()))
sum=0
for i in a:
    sum+=i
print(sum)

