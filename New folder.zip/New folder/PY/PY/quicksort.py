#quick sort
arr=[35,50,15,25,80,20,90,45]

def quickSort(arr):
    def partition(low,high):
        pivot=arr[high]
        i=low-1

        for j in range(low,high):
            if arr[j]<pivot:
                i+=1
                arr[i],arr[j]=arr[j],arr[i]
                
        arr[i+1],arr[high]=arr[high],arr[i+1]
        return i+1
    
    def quickSortRecursive(low,high):
        if low<high:
            pi=partition(low,high)
            quickSortRecursive(low,pi-1)
            quickSortRecursive(pi+1,high)

    quickSortRecursive(0,len(arr)-1)
quickSort(arr)
print(arr)