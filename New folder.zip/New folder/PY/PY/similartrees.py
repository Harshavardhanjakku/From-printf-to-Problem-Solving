class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None

def similarTrees(root1, root2):
    if root1 is None and root2 is None:
        return True
    if root1 is None or root2 is None:
        return False
    if root1.data != root2.data:
        return False
    return similarTrees(root1.left, root2.left) and similarTrees(root1.right, root2.right)

# root1 = Node(10)
# root1.left = Node(20)
# root1.right = Node(30)

# root2 = Node(10)
# root2.left = Node(20)
# root2.right = Node(30)

root1 = Node(10)
root1.left = Node(30)
root1.right = Node(20)

root2 = Node(10)
root2.left = Node(20)
root2.right = Node(30)

print(similarTrees(root1, root2))