apples = [4, 1, -1, 2]
oranges = [6, -7, -5, 1]
a = 5
b = 20
s=7
t=15

apple_count, orange_count = 0, 0
for i in range(len(apples)):
    if a+apples[i] in range(s,t+1):
        apple_count += 1
    if b+oranges[i] in range(s, t+1):
        orange_count+=1
print(f'Apples: {apple_count}, Orange: {orange_count}')

'''for i in apples:
    if a+i>=s and a+i<=t:
        countapple+=1
for j in oranges:
    if b+j>=s and b+i<=t:
        countoranges+=1
print("apples: ",applecount)
print("orranges: ",orangecount)'''