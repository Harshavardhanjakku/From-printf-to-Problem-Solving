a=list(map(int,input().split()))
max=a[0]
for i in a:
    if(max<i):
        max=i
min=a[0]
for i in a:
    if(min>i):
        min=i
print(min, max)