class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
        self.prev=None
class DLL:
    def __init__(self):
        self.head,self.tail=None,None
        
    def insertAtBegin(self,new_data):
        newnode=Node(new_data)
        if self.head==None and self.tail==None:
            self.head=newnode
            self.tail=newnode
        else:
            newnode.next=self.head
            self.head.prev=newnode
            self.head=newnode

    def insertAtEnd(self,new_data):
        newnode=Node(new_data)
        if self.head==None and self.tail==None:
            self.head=newnode
            self.tail=newnode
        else:
            self.tail.next=newnode
            newnode.prev=self.tail
            self.tail=newnode
            newnode.next=None
    def insertAtPos(self,new_data,pos):
        newnode=Node(new_data)
        if self.head==None and self.tail==None and pos==0:
            self.head=newnode
            self.tail=newnode
            return
        if self.head!=None and self.tail!=None and pos==0:
            new_node.next=self.head
            self.head.prev=newnode
            self.head=newnode
            return
        else:
            curr=self.head
            count=0
            while curr and count<pos-1:
                curr=curr.next
                count+=1
            if curr is None:
                print("Out of range")
            newnode.next=curr.next
            curr.next.prev=newnode
            curr.next=newnode
            newnode.prev=curr
            return
            
    def deleteAtBegin(self):
        if self.head==None and self.tail==None:
            print("NO nodes in DLL")
        else:
            temp=self.head
            temp=temp.next
            self.head=temp
            
    def deleteAtEnd(self):
        if self.head==None and self.tail==None:
            print("NO nodes in DLL")
        else:
            temp=self.tail
            self.tail=temp.prev
            self.tail.next=None
    def size(self):
        if self.head==None and self.tail==None:
            print("No nodes in DLL")
        else:
            c=0
            temp=self.head
            while temp:
                c+=1
                print(temp.data)
                temp=temp.next
            return("The size: ",c)
                
    
    def display(self):
        if self.head==None and self.tail==None:
            print('DLL is empty')
        else:
            temp=self.head
            while temp:
                print(temp.data)
                temp=temp.next
    def search(self,target):
        if self.head==None and self.tail==None:
            print("DLL is empty")
        else:
            dorikindhi=False
            temp=self.head
            while temp:
                if temp.data==target:
                    dorikindhi=True
                    break
                temp=temp.next
            if dorikindhi is not True:
                return "elemnet is not found"
            else:
                return "element is  found"
    
        
obj=DLL()
obj.display()
obj.insertAtBegin(20)
obj.insertAtBegin(10)
obj.insertAtBegin(5)
print(obj.size())
obj.display()
print(obj.search(10))
'''obj.insertAtEnd(30)
obj.insertAtEnd(40)
obj.display()
obj.insertAtPos(200,3)
obj.display()'''