a=int(input())
b=int(input())
print("The addition of",a,"and ",b," is",a+b)
print("The subtraction of {} and {} is {} ".format(a,b,a-b))
print(f"The product of {a} and {b} is {a*b}")
print(a/b)
print(a**b)

age=int(input("Enter age: "))
if(age>=18):
    print("U can vote")
else:
    print("SOrry!! U cant vote")
    
