class Animal:
    def eat():
        print("eating....")
    def sound():
        print("sound...")
class Lion(Animal):
    def eat():
        print("Lion eats flesh")
    def sound():
        print("Roar")
class cat(Animal):
    def eat():
        print("Cat eats food")
    def sound():
        print("Meowww")
a=Lion
a.eat()
a.sound()
a1=cat
a1.eat()
a1.sound()
