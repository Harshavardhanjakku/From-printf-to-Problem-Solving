class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None

def preOrder(root):
    if root==None:
        return
    else:
        print(root.data)
        preOrder(root.left)
        preOrder(root.right)
        
def inOrder(root):
    if root==None:
        return
    else:
        inOrder(root.left)
        print(root.data)
        inOrder(root.right)

def postOrder(root):
    if root==None:
        return
    else:
        postOrder(root.left)
        postOrder(root.right)
        print(root.data)
        

def countNode(root):
    if root==None:
        return 0
    elif root.left==None and root.right==None:
        return 1
    elif root.left:
        return countNode(root.left)+countNode(root.right)+1 #+1 for root node
        

def height(root):
    if root==None:
        return -1
    elif root.left==None and root.right==None:
        return 0
    else:
        return (max(height(root.left),height(root.right)))
    
    
def levelOrder(root):
    if root==None:
        return
    else:
        level=[] #queue
        level.append(root)
        while level:
            a=level.pop(0)
            print(a.data)
            if a.left:
                level.append(a.left)
            if a.right:
                level.append(a.right)
        #return level
                
            
        
        
root=Node(10)
root.left=Node(20)
root.left.left=Node(30)
root.left.right=Node(40)
root.right=Node(50)
root.right.left=Node(60)
root.right.right=Node(70)
preOrder(root)
print()
inOrder(root)
print()
postOrder(root)
print()
levelOrder(root)
print("Height: ",height(root))
print("Count of the nodes: ",countNode(root))
