s="i love coding in python"
s=s.split()
s.reverse()
s=' '.join(s)
print((s))
''' letter reverse'''
s="i love coding in python"
s=s[: : -1]
s=''.join(s)
print((s))
