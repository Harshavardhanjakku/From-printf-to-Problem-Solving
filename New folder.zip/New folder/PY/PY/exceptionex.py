def add(a,b):
    return(a+b)
def mul(c,d):
    return(c*d)
try:
    name="Pooja"
    marks=[5,10,12]
    print (marks[8])
except Exception:
    print(add(12,2))
else:
    print(mul(12,2))
finally:
    print("u r done")
