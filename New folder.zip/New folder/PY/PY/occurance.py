'''a=list(map(int,input().split()))
z=len(a)
c=0
n=int(input("ENter the element"))
for i in range(0,z):
        if(a[i]==n):
            c+=1
print(c)'''

#how to find occurance of each element 
l=[1,2,3,1,2,3,4,6]
f={}
c=0
for i in l:
    if i not in f:
        f[i]=1
    else:
        f[i]+=1
        c+=1
    if c>1:
        print("true")
    else:
        print("false")