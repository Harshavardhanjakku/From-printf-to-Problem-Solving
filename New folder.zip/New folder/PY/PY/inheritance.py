class Parent:
    def eat():
        print("this is parent class")
class Child(Parent):
    def food():
        print("I love biryani")
cobj1=Child
cobj1.eat()
cobj1.food()