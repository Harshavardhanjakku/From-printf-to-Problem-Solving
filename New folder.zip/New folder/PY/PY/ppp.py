while(not(not(True)+1):
       print('hehe')
       if 1+1==2:
           print('dont disturb')
           break
       else:
           print('k')
