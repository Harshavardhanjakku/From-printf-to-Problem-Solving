nums=[10,20,30,40,50]
k=3
first=nums[k-1:]
second=nums[:k-1]
print(first+second)

'''def startWithK(nums,k):
    first=nums[k-1:]
    second=nums[:k-1]
    return first+second
print(startWithK(nums,k))'''