try:
    a=15
    b=0
    r=a//b
except Exception as e: # or except ZeroDivisionError
    print(e)
    print("We cannot divide a num by zero")
else:
    print(r)
finally:
    print("u r done with division")
    
    