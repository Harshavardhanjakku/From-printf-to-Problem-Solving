st=[]
s="yaccaz"
for i in s:
        if st and i==st[-1]:
            st.pop()
        else:
            st.append(i)
print(st)
