'''n=6
for i in range(n):
    for j in range(n):
        print('*',end='')
    print()

n=6
for i in range(n):
    for j in range(i+1):
        print('*',end='')
    print()

n=6
for i in range(n):
    for j in range(i,n):
        print('*',end='')
    print()

n=6
for i in range(n):
    for j in range(i,n):
        print('',end=' ')
    for j in range(i+1):
        print('*',end=' ')
    print()

n=6
for i in range(n):
    for j in range(i,n):
        print('',end=' ')
    for j in range(i+1):
        print('*',end='')
    for j in range(i):
        print('*',end='')
    print()
    
n=6
for i in range(n):
    for j in range(n):
        if (i+j==n-1 or i==j):
            print('*',end=' ')
        else:
            print(' ',end=' ')
    print()'''

n=6
for i in range(n):
    for j in range(n):
        if(i==n//2 or j==n//2):
            print('*',end='')
        else:
            print(' ',end='')
    print()
    
