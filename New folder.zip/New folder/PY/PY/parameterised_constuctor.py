#PARAMERTERIZED CONSTRUCTOR
class Employee:
    def __init__(self,name,eid):
        self.name=name
        self.eid=eid
    def __str__(self):
        return(f"Employee name is {self.name} and id is {self.eid}")
e1=Employee("Shreya",1017)
e2=Employee("Sunny",1014)
print(e1)
print(e2)


#STATIC DATA
'''
class Employee:
    #static data
    company='wipro'
    def _init_(self,name,eid,role,salary):
        self.name=name
        self.eid=eid
        self.role=role
        self.salary=salary
    def displayDetails(self):
        print('name is:',self.name)
        print('Employee id:',self.eid)
        print('Employee role:',self.role)
        print('Employee salary:',self.salary)
        print('Employee company:',Employee.company)   (We need to use className and declare it i.e. Employee.company)
e1=Employee('ash',1095,'cse',200000)
e2=Employee('krish',1079,'cse',300000)
e1.displayDetails()
e2.displayDetails()
'''