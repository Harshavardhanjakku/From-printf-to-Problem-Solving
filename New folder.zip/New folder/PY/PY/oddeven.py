'''a=int(input("Enter a num: " ))
if(a%2==0):
    print("Even")
else:
    print("ODD")'''

#WITHOUT USING MODULUS    
a=int(input("Enter a num: " ))
if(a & 1):
    print("ODD")
else:
    print("EVEN")
