#REVERSE OF A ARRAY
'''a=list(map(int,input().split()))
a=a[::-1]
print(a)

#SORTING AN ARRAY
a=list(map(int,input().split()))
a.sort()
print(a)'''

#DUPLICATES IN A ARRAY
a=list(map(int,input().split()))
n=len(a)
print("The duplicate elements are: ")
for i in range(0,n):
    for j in range(i+1,n):
        if (a[i]==a[j]):
            print(a[j],end=' ')