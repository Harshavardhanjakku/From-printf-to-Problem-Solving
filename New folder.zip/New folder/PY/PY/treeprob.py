class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None




def childnode(root):
    if root==None:
        return
    if root.left==None and root.right==None:
        print(root.data)
        
    else:
        if root.left:
                return childnode(root.left),childnode(root.right)
        
root=Node('electronics')
root.left=Node('mobiles')
root.right=Node('laptop')
root.left.left=Node('android')
root.left.right=Node('ios')
root.left.right.right=Node('iphone')
root.left.left.left=Node('samsung')
root.left.left.right=Node('realme')
childnode(root.left.left)