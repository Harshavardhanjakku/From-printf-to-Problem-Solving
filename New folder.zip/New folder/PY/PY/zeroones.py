li=[0,1,0,1,1,0]
zeroes=[]
ones=[]
def zeroOnes(li):
    for i in li:
        if i==0:
            zeroes.append(i)
        else:
            ones.append(i)
    zeroes.extend(ones)
    return(zeroes)
print(zeroOnes(li))
