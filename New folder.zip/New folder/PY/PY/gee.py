class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
class SLL:
    def __init__(self):
        self.head=None
    def iab(self,newdata):
        new_node=Node(newdata)
        if self.head==None:
            self.head=new_node
        else:
            new_node.next=self.head
            self.head=new_node
    def iae(self,newdata):
        new_node=Node(newdata)
        if self.head==None:
            self.head=new_node
        else:
            temp=self.head
            while temp.next:
                temp=temp.next
            temp.next=new_node
    def iap(self,pos,newdata):
        new_node=Node(newdata)
        if self.head==None and pos==0:
            self.head=new_node
            return
        if self.head!=None and pos==0:
            new_node.next=self.head
            self.head=new_node
            return
        else:
            cu=self.head
            c=0
            while cu!=None and c<pos-1:
                cu=cu.next
                c+=1
            if cu is None:
                raise IndexError ("oout of range cant be inserted")
            new_node.next=cu.next
            cu.next=new_node
            return
    def Middle(self):
        slow=self.head
        fast=self.head
        while fast is not None and fast.next is not None:
            slow=slow.next
            fast=fast.next.next
        print("middle : ",slow.data)
    def display(self):
        if self.head==None:
            print("SLL iss empty")
        else:
            temp=self.head
            while temp!=None:
                print(temp.data)
                temp=temp.next
obj1=SLL()
obj1.iab(20)
obj1.iab(30)
obj1.iae(440)
obj1.iab(40)
obj1.Middle()
obj1.iab(50)
obj1.iap(2,220)
obj1.iap(3,330)
obj1.display()
                
            
        