#deque-double ended queue
from collections import deque
nums=deque([10,20,30,40])
nums.popleft()#whenever we want to delete from leftside
nums.pop()
print(nums)