'''encapsulation with access modifiers with private outside the class:'''
class Bank:
    def _init_(self):
        self.name='krishnaaaaaaa'
        self.acc=12345678
        self._amount=100000
        self.__pin=7216
        
obj=Bank()
print(obj.name)
print(obj._amount)
print(obj.Bank_pin)