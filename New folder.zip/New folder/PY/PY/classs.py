#CREATION OF CLASS AND OBJECT
class Student:
    name='Shreya'
    age=19
    depart='CSE'
    roll=1017
s1=Student #CREATION OF OBJECT
print(s1.name,s1.roll)
print(s1.depart)
print(s1.age)
print(f"My name is {s1.name} bearing {s1.roll} belongs to {s1.depart} with age of {s1.age}")