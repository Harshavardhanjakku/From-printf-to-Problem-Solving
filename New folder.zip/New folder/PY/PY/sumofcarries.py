'''sum of carries'''
n1=123
n2=587
sum=0
count=0
carry=0
while n1>0 and n2>0:
    rem1=n1%10
    rem2=n2%10
    sum=rem1+rem2
    if sum>9:
        carry=1
    else:
        carry=0
    count+=carry
    n1=n1//10
    n2=n2//10
print(count)