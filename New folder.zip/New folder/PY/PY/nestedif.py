n=int(input("Enter a num: "))
if(n>0):
    if n>=1 and n<=10:
        print("HELLO")
    else:
        print("BYE!!")
else:
    print("NOT NATURAL")
    