a=list(map(int,input().split()))
print(a)
max=a[0]
min=a[0]
for i in a:
    if max>a[i]:
        max=a[i]
print(max)