'''a=input("enter a string")
if(a==a[::-1]):
    print("is palind")
else:
    print("Is not palin")
a=input("Enter a string: ")
print(a[::-1])
'''
a=list(map(str,input().split()))
print(a[::-1])