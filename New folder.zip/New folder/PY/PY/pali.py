a=input("Enter a string")
if(a==a[::-1]):
    print("Palindrom")
else:
    print("NOT")