class Node:
    def __init__(self,data):
        self.data=data
        self.left=None
        self.right=None

def preOrder(root):
    if root==None:
        return
    else:
        print(root.data)
        preOrder(root.left)
        preOrder(root.right)

def createTree(root):
    data = int(input(f'Enter Left of {root.data} or -1: '))
    if data != -1:
        root.left = Node(data)
        createTree(root.left)
    
    data = int(input(f'Enter Right of {root.data} or -1: '))
    if data != -1:
        root.right = Node(data)
        createTree(root.right)

data = int(input(f'Enter root node or -1: '))
if data == -1:
    print('No Nodes in tree')
else:
    root = Node(data)
    createTree(root)
    preOrder(root)