a=int(input("Entre a: "))
b=int(input("Entre b: "))
c=int(input("Entre c: "))
if(a>b and a>c):
    print("a is big")
elif(b>c):
    print("b is big")
else:
    print("c is big")