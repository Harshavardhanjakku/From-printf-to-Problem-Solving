#Duplicate elemnents
'''a=list(map(int,input().split()))
n=len(a)
for i in range(n):
    for j in range(i+1,n):
        if(a[i]==a[j]):
            print(a[j],end=" ")'''
#OCCURANCE
a=list(map(int,input().split()))
z=len(a)
n=int(input())
c=0
for i in range(z):
        if(a[i]==n):
            c+=1
print(c)
            
            
