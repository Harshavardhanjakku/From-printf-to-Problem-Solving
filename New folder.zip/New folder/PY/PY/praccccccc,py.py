'''Find the Minimum and Maximum Element in an Array
Array Reverse
Write a Program to Cyclically Rotate an Array by One
Sort an Array
Find Duplicates in an Array
Find the Occurrence of an Integer in the Array
a=list(map(int,input().split()))
max=a[0]
for i in a:
    if(i>max):
        max=i
print(max)
min=a[0]
for i in a:
    if(i<min):
        min=i
print(min)
a=list(map(int,input().split()))
a=a[::-1]
print(a)

a=list(map(int,input().split()))
a.sort()
print(a)'''

a=list(map(int,input().split()))
n=len(a)
for i in range(n):
    for j in range(i+1,n):
        if(a[i]==a[j]):
            print(a[i],end=' ')
    
