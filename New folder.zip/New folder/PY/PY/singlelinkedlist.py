'''sll using insertion(beg,end,pos) and deletion(beg,end,del)'''
class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
class SLL:
    def __init__(self):
        self.head=None
        
    def insertAtBegin(self,new_data):
        if self.head==None:
            new_node=Node(new_data)
            self.head=new_node
        else:
            new_node=Node(new_data)
            new_node.next=self.head
            self.head=new_node
    #TO FIND MIDDLE NODE OF A LINKED LIST        
    def Middle(self):
        slow=self.head
        fast=self.head
        while fast is not None and fast.next is not None:
            slow=slow.next
            fast=fast.next.next
        print("Middle data: ",slow.data)
        
    def IndElements(self,ind):
        if self.head==None:
            print("no elements")
        else:
            curr=self.head
            count=0
            while curr and count<=ind:
                print(count,curr.data)
                count+=1
                curr=curr.next
                
        
            
    def display(self):
        if self.head==None:
            print('ll is empty')
        else:
            temp=self.head
            while temp!=None:
                print(temp.data)
                temp=temp.next
                
    def insertatend(self,new_data):
        if self.head==None:
            new_node=Node(new_data)
            self.head=new_node
        else:
            new_node=Node(new_data)
            temp=self.head
            while temp.next:
                temp=temp.next
            temp.next=new_node
            
    def insertatpos(self,new_data,pos):
        new_node=Node(new_data)
        
        #head is not there and pos is 0:
        if self.head==None and pos==0:
            self.head=new_node
            return
        #head is there and pos is 0:
        if self.head!=None and pos==0:
            new_node.next=self.head
            self.head=new_node
            return
        #head is there and pos is not 0:
        else:
            curr=self.head
            count=0
            while curr!=None and count<pos-1:
                curr=curr.next
                count+=1
                
            if curr is None:
                raise IndexError ("oout of range cant be inserted")
            new_node.next=curr.next
            curr.next=new_node
            
            
    def delAtBeginning(self):
        if self.head is None:
            print('No nodes to delete')
        else:
            self.head = self.head.next
    
    def deleteAtPos(self, pos):
        if self.head is None and pos == 0:
            return 'Linked List is Empty'
        if self.head and pos == 0:
            self.head = None
            return 'Node Deleted'
        curr = self.head
        count = 0
        while curr and count < pos-1:
            curr = curr.next
            count += 1
        
        if curr is None:
            return 'Cannot Delete Out Of Range'
        
        temp = curr.next
        curr.next = temp.next
        temp = None
        return 'Node Deleted'
    
    def deleteAtEnd(self):
        if self.head is None:
            print('Linked List is Empty')
        else:
            temp = self.head
            while temp.next.next:
                temp = temp.next
            temp.next = None
            
    def max(self):
        if self.head==None:
            print("empty linked list")
        else:
            temp=self.head
            maxx=temp.data
            while temp!=None:
                if maxx < temp.data:
                      maxx=temp.data
                temp=temp.next
            return maxx
    def min(self):
        if self.head==None:
            print("empty linked list")
        else:
            temp=self.head
            minn=temp.data
            while temp!=None:
                if minn > temp.data:
                    minn=temp.data
                temp=temp.next
            return minn
        
                
obj=SLL()
obj.insertatend(100)
obj.insertatend(200)
obj.insertAtBegin(10)
obj.insertAtBegin(20)
obj.insertatend('sru')
obj.insertAtBegin(30)
obj.insertAtBegin(40)
obj.insertatend(50)
obj.insertatpos(23,4)
obj.insertatpos(64,2)
obj.insertatpos(34,3)
obj.delAtBeginning()
obj.delAtBeginning()
obj.delAtBeginning()
obj.deleteAtPos(1)
obj.deleteAtPos(4)
obj.deleteAtPos(2)
obj.deleteAtEnd()
obj.deleteAtEnd()
obj.deleteAtEnd()
obj.Middle()
obj.IndElements(2)
obj.display()