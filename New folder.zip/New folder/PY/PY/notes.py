n = 9854
res = []

def numberOfNotes(amt, denom):
    res.append(amt//denom)
    return amt - denom*res[-1]

denominations = [500, 100, 50, 10, 5, 1]
for denom in denominations:
    n = numberOfNotes(n, denom)

print(res)