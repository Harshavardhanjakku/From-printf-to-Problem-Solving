'''p1=int(input())
d1=int(input())
s1=int(input())
ff=("The cost of the shirt is: ",(p1*d1/100)+s1)
print(ff)
p2=int(input())
d2=int(input())
s2=int(input())
p3=int(input())
d3=int(input())
s3=int(input())

ss=("The cost of the shirt is: ",(p2-d2/100)+s2)
am=("The cost of the shirt is: ",(p3-d3/100)+s3)
if(ff<ss and ff<am):
    print(ff)
elif(ss<am):
    print(ss)
else:
    print(am)
ff=("The cost of the shirt is: ",(p1-d1%100)+s1)'''


def Online(price,discount,shipping):
    actualprice=(price*discount)/100
    finalprice=price-actualprice
    result =finalprice+shipping
    return result
flipkart=Online(1000,50,50)
snapdeal=Online(900,50,70)
Amezon=Online(800,10,200)
print("flipkart: ",flipkart)
print("snapdeal: ",snapdeal)
print("Amezon: ",Amezon)

def comparison(flipkart,snapdeal,Amezon):
    if flipkart<snapdeal and flipkart<Amezon:
        return "he will prefer flipkart"
    elif snapdeal<Amezon:
        return "he  will prefer snapdeal"
    else:
        return "he will prefer Amezon"
    
print("flipkart: ",flipkart)
print("snapdeal: ",snapdeal)
print("Amezon: ",Amezon)
print(comparison(flipkart,snapdeal,Amezon))




















