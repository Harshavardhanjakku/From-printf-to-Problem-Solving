'''a=list(map(int,input().split()))
count=0
for i in a:
    if (i==1):
        count+=1
print(count)
print(a)'''

a=list(map(int,input().split()))
print(a)
c=0
for i in a:
    if(i%3==0):
        c+=1
print(c)
        