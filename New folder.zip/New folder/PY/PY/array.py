'''n=10
a=[]
for i in range(n):
    a.append(int(input()))
print(a)


#PROB 11111
a,b,c=map(int,input().split())
if(a>b and a>c):
    print("a is big")
elif(b>c):
    print("b is bbig")
else:
    print("c is bigg")'''

a,b=map(int,input().split())
temp=a
a=b
b=temp
print("a is ",a,"b is ",b)
print(f"a is {a} b is {b}")