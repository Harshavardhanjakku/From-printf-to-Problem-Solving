from collections import deque
stack1=[10,20,30,40]
stack1=deque(stack1)

stack2=[]
for _ in range(len(stack1)): #if we dont want to use any variable,
                             #we can use underscore
    stack2.append(stack1.popleft())
print(stack2)