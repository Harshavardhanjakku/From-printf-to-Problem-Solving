class CircularQueue:
    def __init__(self,capacity):
        self.l=[None]*capacity
        self.front=-1
        self.rear=-1
        self.capacity=capacity
    def Enqueue(self,value):
        if(self.rear+1)%self.capacity==self.front:
            print("its full")
            return
        if self.front==-1:
            self.front+=1
        self.rear=(self.rear+1)%self.capacity
        self.l[self.rear]=value
    def dequeue(self):
        if self.front==-1:
           print("it is empty")
           return None
        if self.front==self.rear:
            element=self.l[self.front]
            self.l[self.front]=None
            self.front=-1
            self.rear=-1
            return element
        else:
            element=self.l[self.front]
            self.l[self.front]=None
            self.front=(self.front+1)%self.capacity
            return element
    def display(self):
        if self.front==-1:
           print("it is empty")
           return
        print(*self.l)
    def isfull(self):
        return (self.rear+1)%self.capacity==self.front
    def isempty(self):
        return self.front ==-1
    
q=CircularQueue(5)
q.Enqueue(20)
q.Enqueue(30)
q.Enqueue(40)
q.Enqueue(50)
q.display()
q.dequeue()
q.display()