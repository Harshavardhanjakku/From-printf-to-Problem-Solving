class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def display(self):
        print("Name: ",self.name)
        print("Age: ",self.age)
class Student(Person):
    def __init__(self,name,age,roll,marks):
        super().__init__(name,age)
        self.roll=roll
        self.marks=marks
    def printdata(self):
        print("Name: ",self.name)
        print("Age: ",self.age)
        print("Roll: ",self.roll)
        print("Marks: ",self.marks)
s1=Student('Shreya',19,1017,100)
s1.printdata()
    