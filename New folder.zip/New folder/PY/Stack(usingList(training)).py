class Stack:
    def __init__(self):
        self.stack=[]
    def isempty(self):
        return len(self.stack)==0
    def push(self,item):
        self.stack.append(item)
    def pop(self):
        if not self.isempty():
            temp=self.stack.pop()
            return temp
        else:
            return "stack is empty"
    def peek(self):
       if not self.isempty():
            return self.stack[-1]
       else:
            return "stack is empty"
    def display(self):
        if not self.isempty():
            return self.stack
        else:
            return "stack is empty"
        
ob=Stack()
ob.push(111)
ob.push(112)
ob.push(113)
ob.push(114)
print("stack is :",ob.display())
print("deleted is :",ob.pop())
ob.push(115)
print("topmost  is :",ob.peek())

print("stack is :",ob.display())