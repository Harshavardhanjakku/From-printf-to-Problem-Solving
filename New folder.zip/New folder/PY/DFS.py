graph={0:[1,3],
       1:[0,2,5,6],
       2:[1,3,5,4],
       3:[0,4,2],
       4:[3,2,6],
       5:[1,2],
       6:[1,4]
       }
def dfs(graph,start):
    visited=set()
    stack=[start]
    while stack:
        node=stack.pop()
        if node not in visited:
            print(node,end=' ')
            visited.add(node)
            for neigh in reversed(graph[node]):
                if neigh not in visited:
                    stack.append(neigh)
dfs(graph,5)