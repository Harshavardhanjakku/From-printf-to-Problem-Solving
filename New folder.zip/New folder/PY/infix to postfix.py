class infixtopostfix:
    def __init__(self,infix):
        self.infix_exp=infix
        self.stack=[]
        self.result_string=""
        self.pre={'+':1,'-':1,'*':2,'/':2,'^':3}
    def convertion(self):
        for symbol in self.infix_exp:
            if symbol.isalpha():
                self.result_string+=symbol
            elif symbol =='(':
                self.stack.append(symbol)
            elif symbol ==')':
                while self.stack and self.stack[-1]!='(':
                    self.result_string+=self.stack.pop()
                self.stack.pop()
            elif symbol in self.pre:
                while self.stack and self.stack[-1] in self.pre and self.pre[self.stack[-1]]>=self.pre[symbol]:
                    self.result_string +=self.stack.pop()
                self.stack.append(symbol)
        while self.stack:
              self.result_string +=self.stack.pop()
        return self.result_string
infix=input()
ob=infixtopostfix(infix)
print("Infix Expression:",infix)
print("postfix Expression: ",ob.convertion())