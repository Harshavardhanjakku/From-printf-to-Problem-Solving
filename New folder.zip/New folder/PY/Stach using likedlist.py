#Stack using LINKEDLIST
class Node:
    def __init__(self,data):
        self.data=data
        self.next=None
class StackLL:
    def __init__(self):
        self.top=None
    def push(self,new_data):
        new_node=Node(new_data)
        if self.top==None:
            self.top=new_node
        else:
            new_node.next=self.top
            self.top=new_node
            return
    def pop(self):
        if self.top==None:
            print("Stack Underflow")
        else:
            temp=self.top
            self.top=temp.next
            temp=temp.next
    def peek(self):
        if self.top==None:
            print("stack empty")
        else:
            print("Peak element: ",self.top.data)
    def display(self):
        if self.top==None:
            print("Stack is empty")
        else:
            temp=self.top
            while temp!=None:
                print(temp.data)
                temp=temp.next
obj=StackLL()
obj.push(10)
obj.display()
obj.push(20)
obj.display()
obj.push(30)
obj.display()
obj.pop()
obj.display()
obj.peek()
obj.display()