'''POLYNOMIAl EXPRESSION:
Its kindof linkedlist  in which we stor coefficient,exponent value and next node address,
so these three values is treated as a node.
for example ,if we take 3x^2+2x^+1
-----------------------------------         --------------      ------------
| 3  | 2    | next node address   |------> |2  | 1 | next|----->|1 |0 | NUL|
-----------------------------------         --------------      ------------

'''
class Node:
    def __init__ (self,coef,exp):
        self.coef=coef
        self.next=None
        self.exp=exp
class Pll:
    def __init__(self):
        self.head=None
    def display(self):
        if self.head==None:
            print("0")
            return
        temp=self.head
        while temp!=None:
            if temp.coef!=0:
                if temp.coef>0 and temp!=self.head:
                    print("+",end="")
                print(f"{temp.coef} x^ {temp.exp}",end="")
            temp=temp.next
    
    def ins(self,coef,exp):
        newnode=Node(coef,exp)
        if self.head==None or self.head.exp<exp:
            newnode.link=self.head
            self.head=newnode
        else:
            temp=self.head
            while temp.link and temp.link.exp>=exp:
                temp=temp.link
            newnode.link=temp.link
            temp.link=newnode
ob=Pll()
ob.ins(2,3)
ob.ins(1,2)
ob.ins(3,0)
ob.display()
    