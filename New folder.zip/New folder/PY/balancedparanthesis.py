#BALANCED PARANTHESIS
s=input()
def isB(s):
    stack=[]
    brackets={'(':')','{':'}','[':']'}
    opening=['(','{','[']
    for c in s:
        if c in opening:
            stack.append(c)
        else:
            if not stack:
                return 'false'
            else:
                top=stack[-1]
                if brackets[top]==c:
                    stack.pop()
    if stack==[]:
        return 'true'
    else:
        return 'false'
print(isB(s))