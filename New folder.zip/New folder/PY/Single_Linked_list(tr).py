class Node:
    def __init__ (self,value):
        self.data=value
        self.link=None
class LinkedList:
    def __init__(self):
        self.head=None
    def insert_at_begin(self,value):
        new_node=Node(value)
        if self.head==None:
            self.head=new_node
            return
        new_node.link=self.head
        self.head=new_node
    def insert_at_end(self,value):
        new_node=Node(value)
        if self.head==None:
            self.head=new_node
            return
        temp=self.head
        while temp.link!=None:
            temp=temp.link
        temp.link=new_node
    def insert_before_value(self,value)
        n=int(input("Enter value to insert"))
        new_node=Node(n)
        temp=self.head
        prev=None
        if self.head==None:
            self.head=new_node
            return
        if self.head.data==value:
            new_node.link=self.head
            self.head=new_node
            return
        while temp.data!=value and temp!=None:
            prev=temp
            temp=temp.link
        if temp==None:
            print("Value not found")
            return
        prev.link=new_node
        new_node.link=temp
        return
    def insert_aft_value(self,value):
        n=int(input("Enter value to insert"))
        new_node=Node(n)
        temp=self.head
        if self.head==None:
            self.head=new_node
            return
        while temp.data!=value and temp!=None:
            temp=temp.link
        if temp==None:
            print("Value not found")
            return
        new_node.link=temp.link
        temp.link=new_node
        return
    def del_beg(self):
        if self.head==None:
            print("Linked list is empty")
            return
        self.head=self.head.link
        return
    def del_end(self):
        temp=self.head
        prev=None
        if self.head==None:
            print("List is empty")
            return
        if self.head.link==None:
            self.head=None
        while temp.link!=None:
            prev=temp
            temp=temp.link
        prev.link=None
        return
    def del_bef_val(self,value):
        if self.head==None:
            print("Linked list is empty")
            return
        if self.head.link==None:
            print("Not Possible")
            return
        if self.head.link.data==value:
            self.head=self.head.link
            return
        temp=self.head
        prev=None
        while temp.link!=None and temp.link.data!=value:
            prev=temp
            temp=temp.link
        if temp.link is None:
            print("Value not found")
        prev.link=temp.link
        return
    def traversal(self):
        if self.head==None:
            print("Linked list is empty")
            return
        temp=self.head
        while temp!=None:
            print(temp.data,end="-->")
            temp=temp.link
        print("NULL")
Obj=LinkedList()
Obj.insert_at_begin(111)
Obj.insert_at_begin(222)
Obj.insert_at_begin(333)
Obj.insert_at_end(333)
'''n=int(input())
while n>0:
    element=int(input())
    Obj.insert_at_end(element)
    n=n-1'''
Obj.traversal()
Obj.insert_before_value(222)
Obj.traversal()
Obj.insert_aft_value(222)
Obj.traversal()
Obj.del_beg()
Obj.traversal()
Obj.del_end()
Obj.traversal()
Obj.del_bef_val(6)
Obj.traversal()