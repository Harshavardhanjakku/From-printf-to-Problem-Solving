#WITHOUT CONSTRUCTOR
class Student:
    def getdata(self,name,roll,marks):
        self.name=name
        self.roll=roll
        self.marks=marks
    def putdata(self):
        print("Name : ",self.name)
        print("Roll: ",self.roll)
        print("Marks: ",self.marks)
s1=Student()
s1.getdata("Shreya",1017,100)
s1.putdata()

#WITH CONSTRUCTOR
class Student:
    def __init__(self,name,roll,marks):
        self.name=name
        self.roll=roll
        self.marks=marks
    def display(self):
        print("Name : ",self.name)
        print("Roll: ",self.roll)
        print("Marks: ",self.marks)
    def __del__(self):#Destructor which deltes 
        print("Dlete everything")
        
s1=Student("Shreya",1017,100)
s1.display()
#del s1

#CLASS VARIABLES and INSTANCE Variables




