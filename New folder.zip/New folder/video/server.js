const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const { v4: uuidv4 } = require('uuid');  // UUID for unique room IDs

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.static('public'));

app.get('/create-room', (req, res) => {
    const roomId = uuidv4();  // Generate a unique ID for the room
    res.redirect(`/room/${roomId}`);
});

io.on('connection', (socket) => {
    console.log('A user connected');
    
    socket.on('joinRoom', (room) => {
        socket.join(room);
        console.log(`User joined room: ${room}`);
        
        socket.to(room).emit('newUser', socket.id);

        socket.on('offer', (offer, room) => {
            socket.to(room).emit('offer', offer, socket.id);
        });

        socket.on('answer', (answer, room) => {
            socket.to(room).emit('answer', answer, socket.id);
        });

        socket.on('candidate', (candidate, room) => {
            socket.to(room).emit('candidate', candidate, socket.id);
        });

        socket.on('disconnect', () => {
            console.log('User disconnected');
            socket.to(room).emit('userDisconnected', socket.id);
        });
    });
});

const port = 3000;
server.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
