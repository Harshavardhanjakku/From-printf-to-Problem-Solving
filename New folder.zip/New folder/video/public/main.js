const socket = io();
const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');
const createMeetingButton = document.getElementById('createMeetingButton');
const joinMeetingButton = document.getElementById('joinMeetingButton');
const meetingLinkInput = document.getElementById('meetingLink');
const videoSection = document.getElementById('videoSection');
const createMeetingSection = document.getElementById('createMeeting');
const joinMeetingSection = document.getElementById('joinMeeting');

let localStream;
let peerConnection;
const peers = {};

// WebRTC configuration
const peerConnectionConfig = {
    iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
};

createMeetingButton.addEventListener('click', () => {
    window.location.href = '/create-room';
});

joinMeetingButton.addEventListener('click', () => {
    const meetingLink = meetingLinkInput.value;
    if (meetingLink) {
        const roomId = meetingLink.split('/').pop();  // Extract room ID from link
        joinRoom(roomId);
    } else {
        console.error('No meeting link provided');
    }
});

function joinRoom(room) {
    createMeetingSection.style.display = 'none';
    joinMeetingSection.style.display = 'none';
    videoSection.style.display = 'block';

    console.log(`Joining room: ${room}`);

    navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then(stream => {
            console.log('Media stream obtained');
            localStream = stream;
            localVideo.srcObject = stream;
            localVideo.play();

            // Create peer connection
            peerConnection = new RTCPeerConnection(peerConnectionConfig);
            peers[socket.id] = peerConnection;

            // Add local stream tracks to peer connection
            stream.getTracks().forEach(track => peerConnection.addTrack(track, stream));

            peerConnection.onicecandidate = event => {
                if (event.candidate) {
                    console.log('Sending ICE candidate');
                    socket.emit('candidate', event.candidate, room);
                }
            };

            peerConnection.ontrack = event => {
                console.log('Received remote track');
                remoteVideo.srcObject = event.streams[0];
                remoteVideo.play();
            };

            socket.on('offer', async (offer, id) => {
                console.log('Received offer');
                if (!peers[id]) {
                    const newPeerConnection = new RTCPeerConnection(peerConnectionConfig);
                    peers[id] = newPeerConnection;

                    newPeerConnection.onicecandidate = event => {
                        if (event.candidate) {
                            console.log('Sending ICE candidate for new peer');
                            socket.emit('candidate', event.candidate, room);
                        }
                    };

                    newPeerConnection.ontrack = event => {
                        console.log('Received remote track for new peer');
                        remoteVideo.srcObject = event.streams[0];
                        remoteVideo.play();
                    };

                    await newPeerConnection.setRemoteDescription(new RTCSessionDescription(offer));
                    const answer = await newPeerConnection.createAnswer();
                    await newPeerConnection.setLocalDescription(answer);
                    socket.emit('answer', answer, room);
                }
            });

            socket.on('answer', async (answer, id) => {
                console.log('Received answer');
                if (peers[id]) {
                    await peers[id].setRemoteDescription(new RTCSessionDescription(answer));
                }
            });

            socket.on('candidate', async (candidate, id) => {
                console.log('Received ICE candidate');
                if (peers[id]) {
                    try {
                        await peers[id].addIceCandidate(new RTCIceCandidate(candidate));
                    } catch (e) {
                        console.error('Error adding received ice candidate', e);
                    }
                }
            });

            socket.on('userDisconnected', id => {
                console.log(`User disconnected: ${id}`);
                if (peers[id]) {
                    peers[id].close();
                    delete peers[id];
                }
            });

            console.log('Joining room on server');
            socket.emit('joinRoom', room);
            socket.emit('offer', await peerConnection.createOffer(), room);
        })
        .catch(error => {
            console.error('Error accessing media devices.', error);
        });
}

// Automatically join the room if the user visits a meeting link
const pathArray = window.location.pathname.split('/');
const roomId = pathArray[pathArray.length - 1];
if (roomId !== '') {
    console.log(`Auto-joining room: ${roomId}`);
    joinRoom(roomId);
}
