'''
#FUnction as a argumant
def sq(x):
    return x**2
def apply_func(func,values):
    return [func(v) for v in values]
nums=[1,2,3,4]
print(apply_func(sq,nums))


#Returning a Function

def power_raiser(n):
    def power(x):
        return x**n
    return power
sq=power_raiser(2)
cube=power_raiser(3)
print(sq(5),cube(3))

'''

def sq(x):
    return x**2
def app_fu(func,values):
    return [func(v) for v in values]
nums=[1,2,3,4,5]
print(app_fu(sq,nums))