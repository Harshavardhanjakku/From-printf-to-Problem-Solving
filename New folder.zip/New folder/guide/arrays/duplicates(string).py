a="Shreeeeeyaaaaa"
seen=" "
dup=""
for i in a:
    if i not in seen:
        seen+=i
    else:
        if i not in dup:
            dup+=i
print(dup)
        