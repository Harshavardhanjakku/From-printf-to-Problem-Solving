def sumi(arr):
    summ=0
    for i in arr:
        summ=summ+i
    return summ
arr=[1,2,3,4,5]
print(sumi(arr))
