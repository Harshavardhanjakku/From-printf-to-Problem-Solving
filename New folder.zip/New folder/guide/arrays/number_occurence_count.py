a=[1,2,3,4,3,2,4,5,6,76,76,6,6]
fre={}
for i in a:
    if i not in fre:
        fre[i]=1
    else:
        fre[i]+=1
print(fre)