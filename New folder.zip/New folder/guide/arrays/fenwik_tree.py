a = input()

def eq(a):
    oc, cc = 0, a.count(')')

    for i, c in enumerate(a):
        if oc== cc:
            return i
        if c == ')':
            oc += 1
        elif c == '(':
            cc -= 1
    
    return -1

print(eq(a))