def fib(n):
    if n==0 or n==1:
        return True
    a,b=0,1
    while True:
        c=a+b
        a=b
        b=c
        if c==n:
            return True
        elif c>n:
            return False
n=int(input())
for i in range(n+1):
    if fib(i):
        print(i,end=" ")