
a=[12,5,3]
is_asc=True
for i in range(len(a)):
    for j in range(i,len(a)):
        if a[i]>a[j]:
            is_asc=False
            break
if is_asc:
    print("true")
else:
    print("NOOOOOOOOOOO")
    
'''
a=[1,2,3,4,5]
print("True" if a==sorted(a) else "False")
#the baove is for ascending order
print("True" if a==sorted(a,reverse=True) else "False")
#This chech with descending order
'''