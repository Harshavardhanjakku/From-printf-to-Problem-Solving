//ARRAY REVERSE
def rev(arr):
    l=0
    ri=len(arr)-1
    while l<ri:
        arr[l],arr[ri]=arr[ri],arr[l]
        l+=1
        ri-=1
    return arr
arr=[1,2,3,4,5]
print(rev(arr))

'''

def rev(arr):
    n=len(arr)
    for i in range(n//2):
        arr[i],arr[n-1-i]=arr[n-i-1],arr[i]
    return arr
arr=[1,2,3,4,5]
print(rev(arr))
'''


//STRING REVERSE
def rev(s):
    arr = list(s)   # make list of characters
    l = 0
    ri = len(arr) - 1
    while l < ri:
        arr[l], arr[ri] = arr[ri], arr[l]
        l += 1
        ri -= 1
    return ''.join(arr)   # join back into string

s = "hello"
print(rev(s))
