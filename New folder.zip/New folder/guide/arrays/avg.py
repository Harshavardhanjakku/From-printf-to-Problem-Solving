'''
a=[1,2,3,4,5]
avg=0
sum=0
for i in a:
    sum+=i
    avg=sum//len(a)
print(avg)
'''

import math
a=[1,2,3,4,5]
avg=0
for i in a:
    avg=sum(a)//len(a)
print(avg)