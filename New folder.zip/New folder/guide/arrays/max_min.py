arr=list(map(int,input().split()))
maxi,mini=arr[0],arr[0]
for i in arr:
    if i>maxi:
        maxi=i
    if i<mini:
        mini=i
print(maxi,mini,end=' ')
print("hello")

#end operator is ->it controls what is printed at the end of output of print stattemnt 