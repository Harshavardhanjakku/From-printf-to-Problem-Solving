a=[1,1,2,2,3,3,3]
f={}
for i in a:
    if i not in f:
        f[i]=1
    else:
        f[i]+=1
res=[]
for i in f:
    if i==f[i]:
        res.append(i)
if not res:
    print("No elemnt exists")
else:
    maxi=0
    ans=None
    for i in res:
        if f[i]>maxi:
            maxi=f[i]
            ans=i
    print(ans)