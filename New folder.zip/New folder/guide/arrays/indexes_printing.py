a=[10,30,20,40,66]
p=list(enumerate(a))
def get_value(item):
    return item[1]
p.sort(key=get_value,reverse=True)
res=[]
for index,value in p:
    res.append(index)
print(res)