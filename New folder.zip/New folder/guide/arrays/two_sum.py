#BRUTE FORCE O(n^2)
'''
arr = [2,7,11,15]
target=9
for i in range(len(arr)):
    for j in range(i,len(arr)):
        if arr[i]+arr[j]==target:
            print(arr[i],arr[j])
        
'''

arr= [2,7,11,15]
target=9
seen={}#haspmap
for i,num in enumerate(arr):
    #ennumerate gives u index and value;i-->index,num-->value
    diff=target-num
    if diff in seen:
        print(num,diff)
    else:
        seen[num]=i
    