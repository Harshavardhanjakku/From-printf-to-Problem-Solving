'''
a = [1, 2,3,4,5,7,8]
for i in range(len(a)-1): #len(a)-1;-1 becoz at last if we reach we will not have enext eleement to check if its consecutive or not so stop one before last
    seq=True
    if a[i]+1!=a[i+1]:
        seq=False
        break
if not seq:
    print(a[i]+1)
    
'''

a = [1, 2, 4, 5]
n = 5

total_sum = n * (n + 1) // 2
array_sum = sum(a)

missing = total_sum - array_sum
print("Missing number is:", missing)

'''
this is second method to use
Let’s say the numbers are from 1 to n, but one is missing.

We know two things:

The sum of first n natural numbers is given by:

sum=n(n+1)//2

The sum of the given array will obviously be less than that, because one number is missing.

So,

Missing number = (Sum of 1 to n) − (Sum of array)
'''