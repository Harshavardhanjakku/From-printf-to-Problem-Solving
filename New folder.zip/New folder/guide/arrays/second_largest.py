a=[1,2,3,4,5,99]
max=0
for i in a:
    if i>max:
        a.remove(i)
        if i>max:
            max=i
print(max)