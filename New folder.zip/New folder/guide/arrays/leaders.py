a=[16, 17, 4, 3, 5, 2]
for i in range(len(a)):
    is_leader=True
    for j in range(i,len(a)):
        if a[i]<a[j]:
            is_leader=False
            break
    if is_leader:
        print(a[i],end=' ')
