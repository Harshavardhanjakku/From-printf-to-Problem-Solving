
a=[1,2,0,30,4,3,5,0,0,6,7,0,8,0,9]
s=[]
for i in range(len(a)):
    if a[i]!=0:
        s.append(a[i])
z=a.count(0)
for _ in range(z):
    s.append(0)
print(s)

'''   

arr=[0,1,0,3,12]
a=[]
for i in arr:
    if i !=0:
        a.append(i)
z_c=arr.count(0)
for _ in range(z_c):
    a.append(0)
print(a)



a=[1,2,0,30,4,3,5,0,0,6,7,0,8,0,9]
l=0 #marks the position to place a next non zero leement
for i in range(len(a)):
    if a[i]!=0: #for zeroes at end #if a[i]==0 for zeroes at front
        a[i],a[l]=a[l],a[i]
        l+=1
print(a)

'''
  