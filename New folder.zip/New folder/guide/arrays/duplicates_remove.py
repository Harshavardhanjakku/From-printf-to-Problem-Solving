a=[1,2,4,4,5,6,7,7,8,9,10,3,4,12,12,11]
seen=[]
for i in a:
    if i not in seen:
        seen.append(i)
print(seen)
        