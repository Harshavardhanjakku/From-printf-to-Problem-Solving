def b_b(p):
    best=0
    for i in range(len(p)):
        for j in range(i+1,len(p)):
            pro=p[j]-p[i]
            if pro>best:
                best=pro
    return best
p=[7,1,5,3,6,4]
#p=[7,6,4,3,1]
print(b_b(p))
























def maxProfit_bruteforce(prices):
    n = len(prices)
    best = 0
    for i in range(n):            # buy day
        for j in range(i+1, n):   # sell day after buy
            profit = prices[j] - prices[i]
            if profit > best:
                best = profit
    return best

                       
        