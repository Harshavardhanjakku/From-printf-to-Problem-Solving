a=[1,2,9,-4,3,4,5]
tar=5
for i in range(len(a)):
    for j in range(i,len(a)):
        if a[i]+a[j]==tar:
            print(a[i],a[j])
            #print(i,j)
            
#what if i wnated to print in list the result