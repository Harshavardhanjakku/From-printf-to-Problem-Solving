def isFibonacci(N):
    if N == 0 or N == 1:
        return True
    a, b = 0, 1
    while True:
        c = a + b
        a = b
        b = c
        if c == N:
            return True
        elif c >= N:
            return False
        
n=int(input())
for i in range(1,n):
    if isFibonacci(i):
        print(i,end=' ')