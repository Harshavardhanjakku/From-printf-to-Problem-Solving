LEETCODE 88
2. OPTIMAL APPROACH (O(m+n), in-place)

👉 No extra list
👉 Uses 3 pointers
👉 Merge from backwards
👉 Works even when nums1 has zeros inside
👉 This is the best interview solution

✅ Code (Optimal)
class Solution:
    def merge(self, nums1, m, nums2, n):
        i = m - 1  # pointer at end of valid nums1
        j = n - 1  # pointer at end of nums2
        k = m + n - 1  # pointer at end of nums1 array

        # Run until nums2 is exhausted
        while j >= 0:
            if i >= 0 and nums1[i] > nums2[j]:
                nums1[k] = nums1[i]
                i -= 1
            else:
                nums1[k] = nums2[j]
                j -= 1
            k -= 1

🧠 DRY RUN (Optimal)

Input:

nums1 = [1,2,3,0,0,0], m=3
nums2 = [2,5,6], n=3


i = 2 → pointing to 3
j = 2 → pointing to 6
k = 5 → last index

Step 1

Compare 3 and 6 → bigger is 6
Place it at nums1[5]

nums1 = [1,2,3,0,0,6]
j → 1
k → 4

Step 2

Compare 3 and 5 → bigger is 5
Place at index 4

nums1 = [1,2,3,0,5,6]
j → 0
k → 3

Step 3

Compare 3 and 2 → bigger is 3
Place at index 3

nums1 = [1,2,3,3,5,6]
i → 1
k → 2

Step 4

Compare 2 and 2 → equal → take from nums2
Place at index 2

nums1 = [1,2,2,3,5,6]
j → -1 → STOP


DONE ✔

⭐ FINAL RESULT
[1,2,2,3,5,6]


If you want Chinni, I can also give:

✔ visual diagram
✔ handwritten-like explanation
✔ your favourite beginner dry run table

Just tell me!