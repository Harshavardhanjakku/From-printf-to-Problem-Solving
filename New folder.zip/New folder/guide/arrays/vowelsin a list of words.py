a=["lucknow","warangal","India","Australia"]
v="aeiouAEIOU"
res=[]
for word in a:
    for ch in word:
        if ch in v:
            res.append(ch)
print(res)
        
        
a = ["lucknow", "warangal", "India", "Australia"]
v = "aeiouAEIOU"

for word in a:
    vowels_in_word = [ch for ch in word if ch in v]
    print(f"{word}: {vowels_in_word}")

    