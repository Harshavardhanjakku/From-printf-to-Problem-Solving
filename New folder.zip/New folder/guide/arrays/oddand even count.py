a=[1,2,3,4,5,6,7]
e_c,o_c=0,0
for i in a:
    if i%2==0:
        e_c+=1
    else:
        o_c+=1
print(e_c,o_c)