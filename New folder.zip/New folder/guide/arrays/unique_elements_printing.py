a=[4,5,6,4,7,5,9]
fre={}
for i in a:
    if i in fre:
        fre[i]+=1
    else:
        fre[i]=1
for key,value in fre.items():
    if value==1:
        print(key,end=' ')