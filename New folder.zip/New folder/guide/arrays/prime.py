def prime(n):
    if n==0 or n==1:
        return "neither Prime nor Composite"
    for i in range(2,int(n**0.5)+1):
        if n%i==0:
            return False
    return True
n=int(input())
for i in range(2,n+1):
    if prime(i):
        print(i,end=' ')
