a=[16, 17, 4, 3, 5, 2]

for i in range(len(a)):
    is_leader=True
    for j in range(i,len(a)):
        if a[i]<a[j]:
            is_leader=False
            break
    if is_leader:
        print(a[i],end=' ')
            
            
'''
🟢 Q1: “Why do we write leader = True inside the i loop, not before it?”

Excellent question 👏

Let’s see what would happen if we wrote it before the for i loop.

❌ Wrong place:
leader = True
for i in range(n):
    for j in range(i+1, n):
        ...


If you do this, the variable leader will never reset to True for each new element a[i].
That means — once it becomes False for any element, it stays False forever. 😢

So no future element can ever become a leader, even if it actually is.

✅ Correct place:

We put leader = True inside the outer loop because:

For every new element a[i], we want to start fresh — assume it’s a leader first.

Then check if it gets “disqualified” by finding a larger number on its right.

It’s like checking each student one by one:

“Let’s assume this one is topper… now check marks of everyone to the right. If anyone scores higher, cancel this one.”

You reset your assumption for each new student (i.e., each a[i]).

🟣 Q2: “Why is if leader: written after the inner loop, not under if a[j] > a[i]:?”

Another 🔥 observation!

Let’s see the logic again:

for j in range(i+1, n):
    if a[j] > a[i]:
        leader = False
        break
if leader:
    print(a[i])


We put if leader: after the inner loop because:

We only want to decide after we’ve finished checking all right elements.

During the loop, we’re still in the process of checking.

Only after all checks, we can confirm:
✅ "Okay, no one on the right was greater → print it!"

If we put if leader: inside the inner loop, it would execute multiple times before finishing all comparisons, which breaks the logic.

'''