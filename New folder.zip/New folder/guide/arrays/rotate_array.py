#LEFT ROTATION
a = [1, 2, 3, 4, 5, 6, 7]
k=2
k=k%len(a)#handles the cases where k>length of array
a=a[k:]+a[:k]
print(a)
 
 
 
#RIGHT ROATTAION
a=[1,2,3,4,5]
k=2
k=k%len(a)
a=a[-k:]+a[:-k]
print(a)
 
 
'''    
a[-k:]--->gives us the last elements i.e sarts from -2,-1 i.e 4 and 5
a[:-k]--->gives us the first elements till -2
a[-k:] → last 3 elements → [5, 6, 7]

a[:-k] → all except last 3 → [1, 2, 3, 4]

Combine → [5,6,7] + [1,2,3,4]
'''