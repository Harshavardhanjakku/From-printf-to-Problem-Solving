a=[1,2,4,4,5,6,7,7,8,9,10,3,3,3,4,12,12,11]
seen=[]
dup=[]
for i in a:
    if i not in seen:
        seen.append(i)
    else:
        #if i not in dup:''if we not keep that see the output that u r getting,its like if number is duplicate dand aagain that num occurs u will see in ur dupe list
            dup.append(i)
print(dup)