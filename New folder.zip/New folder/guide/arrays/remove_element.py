n = [0,1,2,2,3,0,4,2]
k = 2
c = 0
r = 0

# count how many are NOT equal to k
for i in range(len(n)):
    if n[i] != k:
        c += 1

# count how many ARE equal to k
for i in range(len(n)):
    if n[i] == k:
        r += 1

# remove all occurrences of k
for i in range(r):
    n.remove(k)

# add '_' r times
for i in range(r):
    n.append('_')

print(n)
print("Valid count:", c)
