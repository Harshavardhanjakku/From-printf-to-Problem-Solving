s="Shreya is a good girl"
e=s.split()
print(len(e[-1]))

