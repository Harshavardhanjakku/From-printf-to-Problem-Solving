
'''
from functools import reduce
nums=[1,2,3,4,5]
add=reduce(lambda a,b:a if a>b else b,nums)
print(add)


nums=[1,2,3,4,5]
add=list(map(lambda a:a**2,nums))
print(add)
'''

nums=[1,2,3,4,5]
add=list(filter(lambda a:a%2==0,nums))
print(add)
