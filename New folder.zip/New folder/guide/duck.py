class Duck:
    def quack(self):
        print("Im duck")
class Person:
    def quack(self):
        print("Person queack!!")
def make_quack(thing):
    thing.quack()
c=make_quack(Duck())
c=make_quack(Person())
    