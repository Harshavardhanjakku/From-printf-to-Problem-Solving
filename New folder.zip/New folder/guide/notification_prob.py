def is_prime(n):
    if n==0 or n==1:
        return False
    for i in range(2,int(n**0.5)+1):
        if n%i==0:
            return False
    return True
def noti(a):
    b=0
    c=0
    for i in a:
        b+=i
        if b>0 and is_prime(b):
            c+=1
    return c  
a=[2,3,-1,4,-2,5]
print(noti(a))