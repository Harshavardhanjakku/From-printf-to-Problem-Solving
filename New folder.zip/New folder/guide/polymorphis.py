class Payment:
    def make_payment(self, amount):
        print("PAYMENT I DONE VIA CREDIT,UI,PAYTM")

class CreditCard(Payment):
    def make_payment(self, amount):
        print(f"Paid ₹{amount} using Credit Card")

class UPI(Payment):
    def make_payment(self, amount):
        print(f"Paid ₹{amount} using UPI")
pay=[CreditCard(),UPI()]
for i in pay:
    i.make_payment(300)