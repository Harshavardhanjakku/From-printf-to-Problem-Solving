'''
arr=[0,1,0,3,12]
l=0
for i in range(len(arr)):
    if arr[i]!=0:
        arr[i],arr[l]=arr[l],arr[i]
        l+=1
print(arr)
        
        '''
#BRUTE FORCE
'''(Taking extra array,appending into new array if element
is not zero then adding extra zeroes to the enfd of new arrya
   ,by cpuntinng the number of zeroes in original array and
   appending them'''

arr=[0,1,0,3,12]
a=[]
for i in arr:
    if i !=0:
        a.append(i)
z_c=arr.count(0)
for _ in range(z_c):
    a.append(0)
print(a)
