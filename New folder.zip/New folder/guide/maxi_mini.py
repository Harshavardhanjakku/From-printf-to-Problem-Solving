def mami(arr):
    maxi=arr[0]
    mini=arr[0]
    for i in arr:
        if i>maxi:
            maxi=i
        if i<mini:
            mini=i
    return maxi,mini
arr=list(map(int,input().split()))
maxi,mini=mami(arr)
print(maxi,mini)
