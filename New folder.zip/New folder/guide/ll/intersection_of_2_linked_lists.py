⭐ Code (for reference)
class Solution:
    def getIntersectionNode(self, headA, headB):
        a, b = headA, headB

        while a != b:
            a = a.next if a else headB
            b = b.next if b else headA
        return a
'''
the above is the same written using ternery operator
if a is not None:
    a = a.next
else:
    a = headB

if b is not None:
    b = b.next
else:
    b = headA
'''

        

🧠 WHY IT WORKS

Let:

lenA = length of list A
lenB = length of list B


Common part length = c

Unique parts:

A unique length = lenA - c
B unique length = lenB - c


Pointer a walks:

A unique → common → B unique → common


Pointer b walks:

B unique → common → A unique → common


Both walk same total distance:

(lenA + lenB)


So they meet at the first node of common part.

🌈 DRY RUN (Clear & Visual)

Let’s take the standard intersection example:

List A: 4 → 1 → 
                 ↘
                  8 → 4 → 5
                 ↗
List B:    5 → 6 → 1 →

🎯 Intersection node = node with value 8
📌 STEP 1 — Start pointers
a = 4 (A)
b = 5 (B)

📌 STEP 2 — Walk one step at a time
Step 1:
a = 1
b = 6

Step 2:
a = 8    (common part)
b = 1

Step 3:
a = 4
b = 8   (common part)

Step 4:
a = 5
b = 4

Step 5:
a = None      (end of A)
b = 5

📌 STEP 3 — a jumps to headB
a = headB = 5
b = 5


Still not equal, continue…

Step 6:
a = 6
b = 4

Step 7:
a = 1
b = None   (end of B)

📌 STEP 4 — b jumps to headA
a = 8
b = headA = 4

Step 8:
a = 4
b = 1

Step 9:
a = 5
b = 8

Step 10:
a = None
b = 4


Next jumps:

a = headB = 5
b = 5

Step 11:
a = 6
b = 1

Step 12:
a = 1
b = 8

Step 13:
a = 8
b = 8  ← 🎉 pointers meet!

💥 Result:
return node with value 8


Pointers meet at the intersection node.

❤️ FINAL UNDERSTANDING IN 1 LINE

Both pointers travel:

A + B


distance, so they sync and meet exactly at the intersection.