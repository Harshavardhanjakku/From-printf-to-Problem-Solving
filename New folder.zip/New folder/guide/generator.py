def count(n):
    c=1
    while c<=n:
        yield c
        c+=1
co=count(3)
print(next(co))
print(next(co))
print(next(co))
#print(next(co))