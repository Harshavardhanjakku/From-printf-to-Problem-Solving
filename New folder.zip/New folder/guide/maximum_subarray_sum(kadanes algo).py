#MAXIMUM SUBARRAY SUM

# Kadane’s Algorithm
arr = [-2,1,-3,4,-1,2,1,-5,4]

max_sum = arr[0]  # take first element as starting max
current_sum = arr[0]

for i in range(1, len(arr)):
    # Step 1: Either take current element OR extend the previous subarray
    current_sum = max(arr[i], current_sum + arr[i])

    # Step 2: Update global maximum
    max_sum = max(max_sum, current_sum)

print("Maximum Subarray Sum (Kadane’s Algorithm):", max_sum)
