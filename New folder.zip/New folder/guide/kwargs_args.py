def add(*ss,**num):
    print( "Args", sum(ss))
    print("Kwargs" ,num)
add(1,2,3,4,5,name="Sh",age=21)

