arr = [16,17,4,3,5,2]
leaders=[]
for i in range(len(arr)):
    for j in range(i,len(arr)):
        if arr[i]<arr[j]:
            break
    else:
        leaders.append(arr[i])
print(leaders)
            
            
            
        