try:
    f=open("abc.txt","w")
    f.write("hello")
except Exception as e:
    print("Error: ",e)
finally:
    f.close()
    print("File closed")
    
    
def divide(a,b):
    if b==0:
        raise ZeroDivisionError("No division with 0")
    return a/b
print(divide(6,3))
print(divide(7,0))