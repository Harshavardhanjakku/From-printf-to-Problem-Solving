class Student:
    def __init__(self,full):
        self.full=full
        print("Constructor is called when object is createsd")
        
s1=Student("Kandhagatla")
print(s1.full)

s2=Student("Arjun")
print(s2.full)