a=input()
l=0
r=len(a)-1
flag=True
while l<r:
    if a[l]!=a[r]:
        flag=False
        break
    l+=1
    r-=1
if flag:
    print("palindrome")
else:
    print("NOOOOOOOOOOOO")
    