def greet(func):
    def wrapper():
        print("Namasthe")
        func()
        print("nice to meet u!!")
    return wrapper
@greet
def hello():
    print( "Hello Shreya")
hello()

