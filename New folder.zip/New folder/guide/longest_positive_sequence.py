def long(a):
    c=0
    maxi=0
    for i in a:
        if i>0:
            c+=1
            if c>=maxi:
                maxi=c
        else:
            c=0
    return maxi
        
    
a=[-1,2,3,4,5,-3,9,10]
print(long(a))
