'''
def maj(a):
    for i in a:
        if a.count(i)>len(a)//2:
            return i
    return -1
           
a=[3,3,4,2,3]
print(maj(a))
'''
def maj(a):
    c=0
    for i in range(len(a)):
        for j in range(i,len(a)):
            if a[j]==a[i]:
                c+=1
        if c>len(a)//2:
            return a[i]
    return -1
a=[3,3,3,4,2]
print(maj(a))
