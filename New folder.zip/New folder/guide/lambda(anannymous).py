nums=[1,2,3,4,5]
sq=list(map(lambda i:i**2,nums))
print(sq)